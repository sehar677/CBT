﻿<%@ Control Language="C#" AutoEventWireup="true" CodeFile="UcChangePassword.ascx.cs"
    Inherits="UserControls_UcChangePassword" %>
<style type="text/css">
    .style6
    {
        height: 25px;
    }
    .style10
    {
        height: 26px;
    }
    .style11
    {
        text-decoration: underline;
    }
</style>
<center>
    <table style="border-color: #5A5D5A; border-width: 1px; width: 29%; left: 384px; position: absolute; top: 104px; height: 208px;" border="1">
        <tr>
            <td style="font-size: x-large">
                &nbsp;<span class="style11">Change Password</span>
            </td>
        </tr>
        <tr>
            <td>
                    <table>
                        <tr>
                            <td>
                                Login Name</td>
                            <td style="text-align: left" class="style6">
                                <asp:TextBox ID="txtUsername" runat="server"></asp:TextBox>
                                <asp:RequiredFieldValidator ControlToValidate="txtUsername" ID="RequiredFieldValidator1"
                                    runat="server" ErrorMessage="*"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td class="style10">
                               Old Password
                            </td>
                            <td style="text-align: left" class="style10">
                                <asp:TextBox ID="txtPassword" runat="server" TextMode="Password"></asp:TextBox>
                                <asp:RequiredFieldValidator ControlToValidate="txtPassword" ID="RequiredFieldValidator2"
                                    runat="server" ErrorMessage="*"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td>
                               New Password
                            </td>
                            <td style="text-align: left">
                                <asp:TextBox ID="txtNewPassword" runat="server" TextMode="Password"></asp:TextBox>
                                <asp:RequiredFieldValidator ControlToValidate="txtNewPassword" ID="RequiredFieldValidator3"
                                    runat="server" ErrorMessage="*"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                        <td colspan="3">
                            <asp:Button ID="btnSubmit" runat="server" Text="Submit" 
                                onclick="btnSubmit_Click" />
                            &nbsp;&nbsp;&nbsp;
                            <asp:Button ID="btnClear" runat="server" Text="Clear" 
                                CausesValidation="False" />
                        </td>
                        </tr>
                        
                    </table>
                <br />
                <center>
                    &nbsp;</center>
    <asp:Label ID="lblMsg" runat="server" 
        style="font-weight: 700; font-size: x-small; font-family: Verdana; color: #FF0000; left: 112px; position: absolute; top: 176px;" ></asp:Label>
            </td>
        </tr>
    </table>
    &nbsp;
</center>
