﻿<%@ Page Language="C#" MasterPageFile="~/DefaultMasterPage.master" AutoEventWireup="true" CodeFile="Default.aspx.cs" Inherits="Default" Title="Computer Based Test" %>
 
<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
 
      
</asp:Content>


