﻿<%@ Page Language="C#" MasterPageFile="~/Student/StudentMasterPage.master" AutoEventWireup="true" CodeFile="frmCheckStatus.aspx.cs" Inherits="Student_frmCheckStatus" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        &nbsp;
        <asp:Panel ID="Panel1" runat="server" Height="392px" Style="left: 88px; position: relative;
            top: -38px" Width="936px">
       <asp:GridView ID="GVCheckStatus" runat="server" AutoGenerateColumns="False" style="left: 24px; position: absolute; top: 24px" Width="888px" BackColor="White" BorderColor="#336666" BorderStyle="Double" BorderWidth="3px" CellPadding="4" GridLines="Horizontal" OnRowEditing="GVCheckStatus_RowEditing">
           <Columns>
             <asp:BoundField DataField="ExamId" HeaderText="ExamId" />    
             <asp:BoundField DataField="ExamName" HeaderText="ExamName" />
             <asp:BoundField DataField="ExamRequestId" HeaderText="Exam Request Id" />       
             <asp:BoundField DataField="DateofSchedule" HeaderText="Date of Schedule" />
             <asp:BoundField DataField="DateOfExam" HeaderText="Date Of Exam" />
             
             <asp:CommandField  ShowEditButton="True" EditText="Go For Exam" />
           </Columns>
           <RowStyle BackColor="White" ForeColor="#333333" />
           <FooterStyle BackColor="White" ForeColor="#333333" />
           <PagerStyle BackColor="#336666" ForeColor="White" HorizontalAlign="Center" />
           <SelectedRowStyle BackColor="#339966" Font-Bold="True" ForeColor="White" />
           <HeaderStyle BackColor="MediumAquamarine" Font-Bold="True" ForeColor="White" />
       </asp:GridView>
       <asp:Label ID="LblMsg" runat="server" style="left: 440px; position: absolute; top: 208px"></asp:Label>
        </asp:Panel>
    </center>
</asp:Content>

