﻿<%@ Page Language="C#" MasterPageFile="~/Student/StudentMasterPage.master" AutoEventWireup="true" CodeFile="frmChangePassword.aspx.cs" Inherits="Student_frmChangePassword" Title="Untitled Page" %>

<%@ Register src="../UserControls/UcChangePassword.ascx" tagname="UcChangePassword" tagprefix="uc1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">

    <uc1:UcChangePassword ID="UcChangePassword1" runat="server" />

</asp:Content>

