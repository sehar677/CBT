﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Student_frmViewRequests : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillgrid();
        }
    }


    BALexam objCheckStatus = new BALexam();
    public void fillgrid()
    {
        objCheckStatus.UserName = Session["User"].ToString();
        GVCheckStatus.DataSource = objCheckStatus.GetRequests();
        GVCheckStatus.DataBind();
        if(GVCheckStatus.Rows.Count==0)
            LblMsg.Text="No Record Found";
        else
            LblMsg.Text = "";
    }



 
 
 
}