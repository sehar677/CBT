﻿<%@ Page Language="C#" MasterPageFile="~/Student/StudentMasterPage.master" AutoEventWireup="true" CodeFile="frmpersonalInfo.aspx.cs" Inherits="Student_frmpersonalInfo" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
<center>
        <table style="left: 435px; position: absolute; top: 136px; width: 296px; height: 344px;">
            <tr>
                <td style="font: 20; font-size: large; background-color: #33cc00; height: 37px;" colspan="2">
                    &nbsp;Account Information
                </td>
            </tr>
            <tr>
                <td align="left" style="height: 39px">
                    Examination</td>
                <td style="height: 39px; width: 189px;">
                    <asp:TextBox ID="TxtExamination" runat="server" Enabled="False" Height="29px" ReadOnly="True"
                        Width="180px"></asp:TextBox></td>
            </tr>
            <tr>
                <td align="left" style="height: 39px">
                    User Id
                </td>
                <td style="height: 39px; width: 189px;">
                    <asp:TextBox ID="txtuserid" runat="server" Height="29px" Width="180px" 
                        ReadOnly="True" Enabled="False"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td align="left">
                    First Name
                </td>
                <td style="width: 189px">
                    <asp:TextBox ID="txtFName" runat="server" Height="29px" Width="180px"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td align="left">
                    Last Name
                </td>
                <td style="width: 189px">
                    <asp:TextBox ID="txtLName" runat="server" Height="29px" Width="180px"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td align="left">
                    Contact No
                </td>
                <td style="width: 189px">
                    <asp:TextBox ID="txtContactNo" runat="server" Height="29px" Width="180px"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td align="left">
                    Address
                </td>
                <td style="width: 189px">
                    <asp:TextBox ID="txtddress" runat="server" Height="29px" Width="180px"></asp:TextBox>&nbsp;</td>
            </tr>
            <tr>
                <td colspan="2" style="height: 30px">
                    <asp:CheckBox ID="chkImage" runat="server" AutoPostBack="True" OnCheckedChanged="chkImage_CheckedChanged"
                        Text="Yes! Upload My Profile Picture" /></td>
            </tr>
            <tr>
                <td colspan="2" style="height: 30px">
                    <asp:Button ID="btnUpdate" runat="server" Text="Update" OnClick="btnUpdate_Click" Height="32px" Width="88px" />&nbsp;
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <asp:Label ID="lblMsg" runat="server"></asp:Label></td>
            </tr>
        </table>
    <asp:SqlDataSource ID="SqlDataSource1" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString %>"
        SelectCommand="SELECT [ExamTypeName] FROM [tbl_ExamType]"></asp:SqlDataSource>
    &nbsp;&nbsp;&nbsp;
    <asp:Panel ID="ImagePanel" runat="server" BorderStyle="None" Height="258px" Style="left: 735px;
        position: absolute; top: 141px; background-color: #ffffff" Visible="False" Width="285px">
        <asp:Label ID="Label1" runat="server" Style="left: 81px; position: absolute; top: 13px"
            Text="Photograph" Width="62px"></asp:Label>
        <asp:Label ID="lblImageMsg" runat="server" Style="left: 20px; position: absolute;
            top: 222px" Text=" " Width="236px"></asp:Label>
        <asp:FileUpload ID="FileUpload1" runat="server" Style="left: 14px; position: absolute;
            top: 158px" Width="243px" />
        &nbsp;&nbsp;
        <asp:Button ID="CmdUplaod" runat="server" CausesValidation="False" OnClick="CmdUplaod_Click"
            Style="left: 60px; position: absolute; top: 187px" Text="Save" Width="110px" />
        <asp:Image ID="Image1" runat="server" Height="106px" Style="left: 51px; position: absolute;
            top: 38px" Width="125px" />
    </asp:Panel>

</center>
</asp:Content>

