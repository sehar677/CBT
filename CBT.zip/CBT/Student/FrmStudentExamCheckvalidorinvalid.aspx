﻿<%@ Page Language="C#" MasterPageFile="~/Student/StudentMasterPage.master" AutoEventWireup="true" CodeFile="~/Student/FrmStudentExamCheckvalidorinvalid.aspx.cs" Inherits="Student_FrmStudentExamCheckvalidorinvalid" Title="Untitled Page" %>

<%--<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
  <style type="text/css">
        .style5
        {
            font-size: large;
            font-weight: bold;
            color: White;
        }
        .style6
        {
            font-size: x-small;
            color: #FF0000;
            text-align: left;
        }
        .txt
        {
            color: Blue;
            vertical-align: top;
            font-weight: bold;
        }
        .style7
        {
        	text-align: left;
        	}
    </style>
</asp:Content>--%>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentBody" Runat="Server">
<center>
        <table border="1" style="border-color: #5A5D5A; border-width: 1px; left: 560px; width: 36%; position: absolute; top: 176px;">
            <tr>
                <td colspan="2" style="font-weight: bold; height: 64px; background-color: gray;" align=center >
                    <span class="style5">Exam Paper Wise Check Date</span><br />
                </td>
            </tr>
            <tr class="style7">
                <td  >
                Exam Date :    
                </td>
                <td>
                <asp:TextBox ID="txtdate" runat="server" ReadOnly="True" Width="208px"></asp:TextBox>
                </td>
            </tr>
            <tr class="style7">
                <td>
               Student Exam Id :    
                </td>
                <td>
                <asp:TextBox ID="txtExamId" runat="server" ReadOnly="True" Width="208px"></asp:TextBox>
                </td>
            </tr>
            <tr class="style7">
                <td>
               Exam Key Code :    
                </td>
                <td>
                <asp:TextBox ID="txtKeycode" runat="server" Width="208px" ></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <br />
                </td>
            </tr>
            &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;
            &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;
                        
                                <tr>
                                    <td style="text-align: right" colspan="2">
                                        &nbsp;<asp:Button ID="btnSubmit" runat="server" Text="Go Exam Paper" OnClick="btnSubmit_Click"
                                            Style="font-weight: 700; left: -114px; position: relative; top: 0px;" ValidationGroup="b" Width="128px" />&nbsp;&nbsp;
                                        </td>
                                  
                                </tr>        &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;
            &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;
            
            <tr>
                <td colspan="2">
                    <asp:Label ID="lblMsg" runat="server"></asp:Label>
                </td>
            </tr>
            </table>
        <br />
    </center>
</asp:Content>

