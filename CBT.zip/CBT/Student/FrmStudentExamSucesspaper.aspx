﻿<%@ Page Language="C#" MasterPageFile="~/Student/StudentMasterPage.master" AutoEventWireup="true"
    CodeFile="~/Student/FrmStudentExamSucesspaper.aspx.cs" Inherits="Student_FrmStudentExamSucesspaper"
    Title="Untitled Page" %>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentBody" runat="Server">
    <center>
        <br />
        <br />
        <h3>
            &nbsp;</h3>
    </center>
    <center>
        <asp:Panel ID="Panel1" runat="server" Height="384px" Style="left: 280px; position: absolute;
            top: 136px" Width="952px">
                    <asp:GridView ID="gridresult" runat="server"
                        CellPadding="4" GridLines="None"
                        Width="936px" Height="50px" style="left: 8px; position: absolute; top: 8px">
                        <FooterStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" />
                        <RowStyle BackColor="#F7F6F3" ForeColor="#333333" />
                        <PagerStyle BackColor="#284775" ForeColor="White" HorizontalAlign="Center" />
                        <SelectedRowStyle BackColor="#E2DED6" Font-Bold="True" ForeColor="#333333" />
                        <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" />
                        <EditRowStyle BackColor="#999999" />
                        <AlternatingRowStyle BackColor="White" ForeColor="#284775" />
                    </asp:GridView>
        <asp:Label ID="lblError" runat="server" style="left: 448px; position: absolute; top: 320px"></asp:Label>
        </asp:Panel>
        &nbsp;<br />
        <br />
        <br />
        <br />
        &nbsp;</center>
</asp:Content>