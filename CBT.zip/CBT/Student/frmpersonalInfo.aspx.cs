﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Data.SqlClient;
using System.Drawing;

public partial class Student_frmpersonalInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            Fill();
        }
    }

    public void Fill()
    {
        DataSet ds1 = BALStudent.Getusername(Session["User"].ToString());
        if (ds1.Tables[0].Rows.Count != 0)
        {
            txtuserid.Text = ds1.Tables[0].Rows[0][0].ToString();
            txtFName.Text = ds1.Tables[0].Rows[0][1].ToString();
            txtLName.Text = ds1.Tables[0].Rows[0][2].ToString();
            txtContactNo.Text = ds1.Tables[0].Rows[0][3].ToString();
            txtddress.Text = ds1.Tables[0].Rows[0][4].ToString();
            TxtExamination.Text = ds1.Tables[0].Rows[0][5].ToString();
        }
        else
        {
            lblMsg.Text = "No Record Found";
        }
    }



    BALStudent updateobj = new BALStudent();
    BALexam objAttemptexam = new BALexam();

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OnlineWebBasedExam"].ConnectionString.ToString());
    SqlCommand cmd = new SqlCommand();

    protected void btnUpdate_Click(object sender, EventArgs e)
    {

        try
        {
             updateobj.updateAccountinfo(Convert.ToInt32(txtuserid.Text), txtFName.Text, txtLName.Text, txtContactNo.Text, txtddress.Text);
             lblMsg.ForeColor = System.Drawing.Color.ForestGreen;
             lblMsg.Text = "Record Updated Successfully "; 
             Fill(); 
            //string ImageUrl = "~/Upload/" + txtuserid.Text+".jpg"; 
            /*
            Byte[] imgByte = null;
            if (img.PostedFile != null)
            {
                HttpPostedFile File = img.PostedFile;
                imgByte = new Byte[File.ContentLength];
                File.InputStream.Read(imgByte, 0, File.ContentLength);
                //cmd.CommandText = "update tbl_UserDetails set image=@Image where userid=" + txtuserid.Text;
                cmd.CommandText = "Update tbl_userDetails set image=@Image,Fname='" + txtFName.Text + "', lname='" + txtLName.Text + "',contactno='" + txtContactNo.Text + "',address='" + txtddress.Text + "' where userid=" + txtuserid.Text;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@Image", imgByte);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                lblMsg.ForeColor = System.Drawing.Color.ForestGreen;
                lblMsg.Text = "Record Updated Successfully
                Fill(); 
            } 
            */             
                          
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }

    }


    protected void chkImage_CheckedChanged(object sender, EventArgs e)
    {
       /* if (chkImage.Checked == true)
        {
            ImagePanel.Visible = true;
            chkImage.Checked = true;
        }
        else
        {
            ImagePanel.Visible = false;
            chkImage.Checked = false;
        }*/
    }



    protected void CmdUplaod_Click(object sender, EventArgs e)
    {
        lblImageMsg.Text = "";
        if (FileUpload1.HasFile)
        {

            string strname = txtuserid.Text + ".jpg";
            string folderPath = Server.MapPath("~/upload/");
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }
            FileUpload1.PostedFile.SaveAs(folderPath + strname);
            Image1.ImageUrl = "~/upload/" + strname;
            lblImageMsg.Text = "Image Saved Successfully";


            byte[] bytes;
            BinaryReader br = new BinaryReader(FileUpload1.PostedFile.InputStream);
            bytes = br.ReadBytes(FileUpload1.PostedFile.ContentLength);

            cmd.Connection = con;
            cmd.CommandText = "update tbl_UserDetails set image=@Image where userid=" + txtuserid.Text;
            cmd.Parameters.AddWithValue("@Image", bytes);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            lblImageMsg.Text = "Image Saved Successfully";


  
           //to test byte array
           //string imageUrl = "~/Upload/" + "sabi.jpg";
           //File.WriteAllBytes(Server.MapPath(imageUrl), bytes); 
             

        }

    }
}