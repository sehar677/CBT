﻿<%@ Page Language="C#" MasterPageFile="~/Student/StudentMasterPage.master" AutoEventWireup="true"
    CodeFile="~/Student/FrmStudentExaminationPaper.aspx.cs" Inherits="Student_FrmStudentExaminationPaper"
    Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/Student/StudentMasterPage.master" %>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentBody" runat="Server">
<script type="text/javascript" language="javascript" >
window.history.forward(1)
</script>
    <center>
        <br />
        <table width="60%" border="1" style="border-color: #5A5D5A; border-width: 1px; left: 352px; position: absolute; top: 128px;">
            <tr>
                <td style="width: 760px">
                    <span class="style5">&nbsp;Examination Paper </span>
                </td>
            </tr>
            <tr>
                <td style="width: 760px">
                    <br />
                </td>
            </tr>
            <tr>
                <td style="width: 760px">
                    <table width="100%">
                        <tr>
                            <td >
                                <asp:GridView ID="GridView1" Width="100%" AutoGenerateColumns="False" runat="server"
                                    CellPadding="4" ForeColor="#333333" GridLines="None" PageSize="1" ShowFooter="True" Height="736px">
                                    <PagerSettings NextPageText="Submit" />
                                    <FooterStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" />
                                    <RowStyle BackColor="#F7F6F3" ForeColor="#333333" />
                                    <PagerStyle BackColor="#284775" ForeColor="White" HorizontalAlign="Center" />
                                    <SelectedRowStyle BackColor="#E2DED6" Font-Bold="True" ForeColor="#333333" />
                                    <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" />
                                    <EditRowStyle BackColor="#999999" />
                                    <AlternatingRowStyle BackColor="White" ForeColor="#284775" />
                                    <Columns>
                                        <asp:TemplateField>
                                            <ItemTemplate>
                                                <table width="100%">
                                                    <tr>
                                                        <td colspan="4" >
                                                            <asp:Panel BackColor="#00ffcc" ID="panel" Width="100%" Height="20%" runat="server">
                                                                <asp:Label ID="Label1" CssClass="txt" runat="server" Text="Question :"></asp:Label>
                                                                <asp:TextBox ID="txtQuestion" ReadOnly="true" Width="92%" Text='<%#Eval("QuestionText") %>'
                                                                    runat="server" TextMode="MultiLine"></asp:TextBox>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="panelRadio" Width="100%" Height="20%" runat="server">
                                                                <tr>
                                                                    <td >
                                                                        <asp:RadioButton ID="RadioButton1" Text='<%#Eval("Answer1")%>' GroupName="b1" runat="server" />
                                                                    </td>
                                                                    <td  >
                                                                        <asp:RadioButton ID="RadioButton2" Text='<%#Eval("Answer2")%>' GroupName="b1" runat="server" />
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td >
                                                                        <asp:RadioButton ID="RadioButton3" Text='<%#Eval("Answer3")%>' GroupName="b1" runat="server" />
                                                                    </td>
                                                                        <td>
                                                                        <asp:RadioButton ID="RadioButton4" Text='<%#Eval("Answer4") %>' GroupName="b1" runat="server" />
                                                                        <asp:Label ID="lblQuestionId" Visible="false" Text='<%#Eval("QuestionSNo")%>' runat="server"></asp:Label>
                                                                        <asp:Label ID="lblcorrectAnswer" Visible="false" Text='<%#Eval("CorrectAnswer")%>' runat="server"></asp:Label>
                                                                        <asp:Label ID="lblNoofmarks" Visible="false" Text='<%#Eval("Marks")%>' runat="server"></asp:Label>
                                                                    </td>
                                                                </tr>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </ItemTemplate>
                                            <ControlStyle Width="100%"></ControlStyle>
                                            <FooterTemplate>
                                                <center>
                                                    <asp:LinkButton ID="linkSubmit" Font-Size="X-Large" ForeColor="White" runat="server"
                                                        Text="Submit" OnClick="Submit_Click"></asp:LinkButton></center>
                                            </FooterTemplate>
                                        </asp:TemplateField>
                                    </Columns>
                                </asp:GridView>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td style="width: 760px">
                    <br />
                </td>
            </tr>
            <tr>
                <td style="width: 760px">
                    <asp:Label ID="lblMsg" runat="server"></asp:Label>
                </td>
            </tr>
            </table>
            <asp:Label ID="lblStartTime" runat="server" Text="" Visible="false" style="left: 576px; position: absolute; top: 104px"></asp:Label>
            <asp:Label ID="lblEndTime" runat="server" Text="" Visible="false" style="left: 664px; position: absolute; top: 104px"></asp:Label>
            <asp:Label ID="lblFinalTime" runat="server" Text="" Visible="false" style="left: 752px; position: absolute; top: 104px"></asp:Label>

    </center>



        </asp:Content>