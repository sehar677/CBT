﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Student_FrmStudentExamCheckvalidorinvalid : System.Web.UI.Page
{
    BALexam objexamcheck = new BALexam();
    static string Status, Keycode;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                int VarExamId, VarRequestId;
                VarExamId = Convert.ToInt32(Session["ExamId"]);
                VarRequestId = Convert.ToInt32(Session["ExamRequestId"]);
                DataSet ds = objexamcheck.ShowExamRequestDetails(VarExamId,VarRequestId);
                if (ds.Tables[0].Rows.Count != 0)
                {
                    txtdate.Text = ds.Tables[0].Rows[0][4].ToString();
                    txtExamId.Text = ds.Tables[0].Rows[0][2].ToString();
                    ViewState["status"] = ds.Tables[0].Rows[0][8];
                    ViewState["KeyCode"] = ds.Tables[0].Rows[0][6];
                    Status = ds.Tables[0].Rows[0][8].ToString();
                    Keycode = ds.Tables[0].Rows[0][6].ToString ();
             
                }
                else
                {
                    txtdate.Text = "Missed out"; 
                    txtExamId.Text = "or"; 
                    txtKeycode.Text ="Not Sheduled Yet";
                }
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }



    


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            DateTime VarDate = DateTime.Today;
            string VarStr = string.Format("{0:dd/MM/yyyy}", VarDate);  

            DateTime VarTxtDate =Convert.ToDateTime(txtdate.Text);
            string VarStrText = string.Format("{0:dd/MM/yyyy}", VarTxtDate);  
       
            if (VarStr == VarStrText ) 
            {       
                if (txtKeycode.Text == Keycode)           
                {         
                             if (Status=="0")                                         
                             {
                                 Response.Redirect("FrmStudentExaminationPaper.aspx");
                             }
                             else
                             {
                                 lblMsg.Text = "Already Exam is Attend ..So Attend Another Exam... ";
                             }                   
                }
                else
                {
                              lblMsg.Text="Invalid Exam Code ";
                 }
            }
            else 
            {
            lblMsg.Text = "Exam not Available Today...";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}