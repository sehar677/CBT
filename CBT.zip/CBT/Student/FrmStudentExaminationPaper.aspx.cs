﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Student_FrmStudentExaminationPaper : System.Web.UI.Page
{
    
    BALQuestionPaper objexamdetails = new BALQuestionPaper();
    BALexam objCheckStatus = new BALexam();    
    protected void Page_Load(object sender, EventArgs e)
    {
        int id;
        string  UserName;
        try
        {
            if (!IsPostBack)
            {

                id = Convert.ToInt32(Session["ExamId"]);               
                UserName = Session["User"].ToString() ;
                //objCheckStatus.ExamId = 58;           
               // min = 20; 
                objCheckStatus.ExamId = id;
                int min = objCheckStatus.getExamDuration();
                this.Master.StartTimer(min);
                          

                GridView1.DataSource = BALQuestionPaper.ShowExaminationAllDetails(id, UserName);
                GridView1.DataBind();
                BALQuestionPaper.Updatestatus(UserName,id, 2);
                lblStartTime.Text = DateTime.Now.ToLongTimeString().ToString();
            }
        }
        catch(Exception ex)
        {
            lblMsg.Text = ex.Message;
            Response.Write("<script>alert('" + ex.Message + "')</script>");
        }
    }



 

  public void Submit_Click(object sender, EventArgs e)
  {
     try
     {         
      int id;
      string UserName;
      TimeSpan timediff;
      int NoOfQues;
      int outques;
      string text;
      int  marks;

      id = Convert.ToInt32(Session["ExamId"]);
      UserName = Session["User"].ToString();

      lblEndTime.Text = DateTime.Now.ToLongTimeString().ToString();
      DateTime dt = DateTime.Parse(lblStartTime.Text);
      DateTime dt2 = DateTime.Parse(lblEndTime.Text);
      timediff = dt2.Subtract(dt);
      lblFinalTime.Text = timediff.ToString() + " Min";

      int attemptcount, correctAnsCount, wrongAnsCount;
      RadioButton r1, r2, r3, r4;
      Label lblCorrectAnswer, lblNoMarks, lblQuestionID;
   


           
            attemptcount= correctAnsCount= wrongAnsCount=marks = 0;
            foreach(GridViewRow item in GridView1.Rows)
            {
                text = "No Response";
                lblCorrectAnswer = (Label)item.FindControl("lblcorrectAnswer");
                lblNoMarks = (Label)item.FindControl("lblNoofmarks");
                lblQuestionID = (Label)item.FindControl("lblQuestionId");
                r1 = (RadioButton)item.FindControl("RadioButton1");
                r2 = (RadioButton)item.FindControl("RadioButton2");
                r3 = (RadioButton)item.FindControl("RadioButton3");
                r4 = (RadioButton)item.FindControl("RadioButton4");

                if (r1.Checked || r2.Checked || r3.Checked || r4.Checked)
                {
                    if (r1.Checked)
                    {
                        text = r1.Text;
                    }
                    if (r2.Checked)
                    {
                        text = r2.Text;
                    }
                    if (r3.Checked)
                    {
                        text = r3.Text;
                    }
                    if (r4.Checked)
                    {
                        text = r4.Text;
                    }
                 
                    if (lblCorrectAnswer.Text.Trim() == text.Trim())
                        {
                            objexamdetails.InsertStudentExaminationDetails(id, lblQuestionID.Text, text, true);
                            marks += Convert.ToInt32(lblNoMarks.Text);
                            correctAnsCount += 1;
                        }
                        else
                        {
                            objexamdetails.InsertStudentExaminationDetails(id, lblQuestionID.Text, text, false);
                            wrongAnsCount += 1;
                        }
                  
                   attemptcount = attemptcount + 1;
                }
                else
                {
                    objexamdetails.InsertStudentExaminationDetails(id,lblQuestionID.Text,text,false);
                }
      }

  

      objexamdetails.FindQuestions(out outques, id);
      NoOfQues = outques;
      BALQuestionPaper.InsertstudentResults(UserName, id, NoOfQues, correctAnsCount, wrongAnsCount, attemptcount, marks, timediff.ToString());

      BALQuestionPaper.Updatestatus(UserName, id, 1);

      Response.Redirect("~/Student/FrmStudentExamSucesspaper.aspx?Examid=" + id + "&UserName=" + UserName);
      }
      catch (Exception ex)
      {
        lblMsg.Text = ex.Message;
        Response.Write("<script>alert('" + ex.Message + "')</script>");
      }
      
    } 




   
    
    
   
    
}