﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Student_frmRequestforExam : System.Web.UI.Page
{
    BALexam examdaterequest = new BALexam();
    BALexam objAttemptexam = new BALexam();
    protected void Page_Load(object sender, EventArgs e)
    {       
        try
        {
            if (!IsPostBack)
            {
                string strMsg;
                objAttemptexam.UserName = Session["User"].ToString();
                objAttemptexam.getExamination(out strMsg);
                txtexamtype.Text = strMsg;
            }

        }
        catch (Exception ex)
        {
            txtexamtype.Text = ex.Message;
        }
        

        try
        {
            if (!IsPostBack)
            {   string strMsg;
                objAttemptexam.Examtypename = txtexamtype.Text;
                objAttemptexam.getExamTypeID(out strMsg);
                txtexamtypeid.Text = strMsg;
            }
        }
        catch (Exception ex)
        {
            txtexamtype.Text = ex.Message;
        }



        try
        {
            if (!IsPostBack)
            {
                ddlExamName.DataSource = examdaterequest.getExamName(txtexamtypeid.Text);
                ddlExamName.DataValueField = "ExamId";
                ddlExamName.DataTextField = "ExamName";
                ddlExamName.DataBind();
            }
        }
        catch (Exception ex)
        {
            txtexamtype.Text = ex.Message;
        }
      
      

    }



    protected void ddlExamTypeName_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            examdaterequest = new BALexam();
            examdaterequest.ExamReqDate = txtExamDate.Text;
            examdaterequest.ExamId =Convert.ToInt32(ddlExamName.SelectedValue);
            examdaterequest.Examtypeid = Convert.ToInt32(txtexamtypeid.Text);
            examdaterequest.UserName=Session["User"].ToString();
            examdaterequest.CurStatus = "Not Sheduled";

            string strMsg;
            int i = examdaterequest.InsertExamRequest(out strMsg);
             if (i > 1)
            {
                ClearData();
                lblMsg.Text = strMsg;         
            }
            else
                lblMsg.Text = strMsg;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    private void ClearData()
    {
        txtExamDate.Text = "";
    }






    protected void ddlExamName_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
