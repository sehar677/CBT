﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Student_Index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
                if (Session["Role"].ToString() == "ADMIN")
                 Response.Redirect("~/admin/Index.aspx");
        }
        catch (Exception ex)
        {
             Response.Write("<script>alert('" + ex.Message + "')</script>");
             

        }

    }
}
