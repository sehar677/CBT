﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Student_frmCheckStatus : System.Web.UI.Page
{
   BALexam objCheckStatus = new BALexam();    
    
    protected void Page_Load(object sender, EventArgs e)
    {
    
        if (!IsPostBack)
        {                      
            fillgrid();
        }
    }


  
    public void fillgrid()
    {
        objCheckStatus.UserName = Session["User"].ToString();
        GVCheckStatus.DataSource = objCheckStatus.GetCheckStatus();
        GVCheckStatus.DataBind();
        if (GVCheckStatus.Rows.Count == 0)
            LblMsg.Text = "No Record Found";
        else
            LblMsg.Text = "";
 


    }
    


    protected void GVCheckStatus_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            Session["ExamId"] = Convert.ToInt32(GVCheckStatus.Rows[e.NewEditIndex].Cells[0].Text);
            Session["ExamRequestId"] = Convert.ToInt32(GVCheckStatus.Rows[e.NewEditIndex].Cells[2].Text);
            Response.Redirect("FrmStudentExamCheckvalidorinvalid.aspx");
        }
        catch (Exception ex)
        {
            LblMsg.Text =  ex.Message;
        }
    }
}