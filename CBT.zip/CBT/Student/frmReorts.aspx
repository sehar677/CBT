<%@ Page Language="C#" MasterPageFile="~/Student/StudentMasterPage.master" AutoEventWireup="true" CodeFile="frmReorts.aspx.cs" Inherits="Student_frmReorts" Title="Untitled Page" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    &nbsp;
    <asp:Panel ID="UserPanel" runat="server" BorderStyle="None" Height="64px" Style="left: 302px;
        position: absolute; top: 12px; background-color: white; z-index: 103;" Width="274px">
        <asp:Label ID="Label5" runat="server" Font-Names="Calibri" Style="left: 12px; position: absolute;
            top: 4px; font-family: 'Monotype Corsiva';" Text="Name" Width="66px" BorderStyle="None" Font-Bold="True"></asp:Label>
        &nbsp;
        <asp:Label ID="Label2" runat="server" Font-Names="Calibri" Style="left: 165px; position: absolute;
            top: 4px; font-family: 'Monotype Corsiva';" Text="User Id" Width="64px" BorderStyle="None" Font-Bold="True"></asp:Label>
        &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
        <asp:Label ID="txtusername" runat="server" BorderStyle="None" Font-Names="Calibri"
            Style="left: 10px; position: absolute; top: 29px; font-family: 'Monotype Corsiva';" Text="Name" Width="148px"></asp:Label>
        <asp:Label ID="TxtUserId" runat="server" BorderStyle="None" Font-Names="Calibri"
            Style="left: 162px; position: absolute; top: 29px; font-family: 'Monotype Corsiva';" Text="User Id" Width="64px"></asp:Label>
    </asp:Panel>
    <asp:GridView ID="GVScheduleExam" runat="server" AutoGenerateColumns="False" BackColor="White"
        BorderColor="#336666" BorderStyle="Double" BorderWidth="3px" CellPadding="4"
        GridLines="Horizontal" Style="left: 298px; position: absolute; top: 137px; z-index: 101;" Width="880px">
        <Columns>
            <asp:BoundField DataField="ExamId" HeaderText="ExamId" />
            <asp:BoundField DataField="ExamName" HeaderText="ExamName" />
            <asp:BoundField DataField="NoOfQuestion" HeaderText="No Of Questions" />
            <asp:BoundField DataField="CorrectAnswers" HeaderText="CorrectAnswers" />
            <asp:BoundField DataField="WrongAnswers" HeaderText="Wrong Answers" />
            <asp:BoundField DataField="Attempted" HeaderText="Attempted" />
            <asp:BoundField DataField="NetScore" HeaderText="NetScore" />
            <asp:BoundField DataField="TimeTaken" HeaderText="TimeTaken" />
            <asp:BoundField DataField="ExamAttendedDate" HeaderText="ExamAttendedDate" />
        </Columns>
        <EmptyDataTemplate>
            No Data In The Table
        </EmptyDataTemplate>
        <RowStyle BackColor="White" ForeColor="#333333" />
        <FooterStyle BackColor="White" ForeColor="#333333" />
        <PagerStyle BackColor="#336666" ForeColor="White" HorizontalAlign="Center" />
        <SelectedRowStyle BackColor="#339966" Font-Bold="True" ForeColor="White" />
        <HeaderStyle BackColor="#336666" Font-Bold="True" ForeColor="White" />
    </asp:GridView><asp:Panel ID="Panel1" runat="server" BorderStyle="None" Height="64px" Style="left: 586px;
        position: absolute; top: 14px; background-color: white; z-index: 102;" Width="205px">
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<asp:SqlDataSource ID="SqlDataSourceGrid" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString9 %>"
            SelectCommand="SELECT [UserId], [ExamId], [NoOfQuestion], [CorrectAnswers], [WrongAnswers], [Attempted], [NetScore], [TimeTaken], [ExamAttendedDate] FROM [tbl_ExamResult] WHERE ([UserId] = @UserId)">
            <SelectParameters>
                <asp:ControlParameter ControlID="TxtUserId" Name="UserId" PropertyName="Text" Type="Int32" />
            </SelectParameters>
        </asp:SqlDataSource>
        &nbsp;&nbsp;
    </asp:Panel>
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <asp:Label ID="LblMsg" runat="server" Style="left: 686px; position: absolute; top: 118px"
        Text=""></asp:Label>
    <br />
    <br />
    <br />
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
</asp:Content>

