﻿
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using OnlineWebBasedExam;

public partial class Student_FrmStudentExamSucesspaper : System.Web.UI.Page
{
    BALQuestionPaper objresult = new BALQuestionPaper();
    static int ExamId;
    static string UserName;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                UserName = Convert.ToString (Request["UserName"]);
                ExamId = Convert.ToInt32(Request["Examid"]);                
                gridresult.DataSource = objresult.DisplayResult(ExamId, UserName);
                gridresult.DataBind();
                lblError.Text = "Exam Successfulyy Completed";
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            Response.Write("<script>alert('" + ex.Message + "')</script>");
        } 
    }
     
}