﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

public partial class Student_StudentMasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {              
             lblLoginName.Text = Session["User"].ToString();         
            
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
                Response.Redirect("~/Registration/Login.aspx");
            }
        }
    }

    protected void LinkButton8_Click(object sender, EventArgs e)
    {
        FormsAuthentication.SignOut();
        Session.Abandon();
        Session.Clear();
        Response.Redirect("~/Default.aspx"); 
    }

    protected void TimerTest_tick(object sender, EventArgs e)
    {   
         
            if (DateTime.Compare(DateTime.Now, DateTime.Parse(Session["Timer"].ToString())) < 0)
            {
                LitMsg.Text = "Time Left:  " + ((Int32)DateTime.Parse(Session["Timer"].ToString()).Subtract(DateTime.Now).TotalMinutes).ToString() + " Minutes " + (((Int32)DateTime.Parse(Session["Timer"].ToString()).Subtract(DateTime.Now).TotalSeconds) % 60).ToString() + " Seconds ";
            }
            else
            {
                LitMsg.Text = "Time Over";
                
            }      
    }
    public void  StartTimer(int min)
    {
        if (!IsPostBack)
        {
            Session["Timer"] = DateTime.Now.AddMinutes(min).ToString();
            TimerTest.Enabled = true;
        }
    }
    public void StopTimer()
    {
        TimerTest.Enabled = false;
    }
}
