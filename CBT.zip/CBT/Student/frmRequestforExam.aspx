﻿<%@ Page Language="C#" MasterPageFile="~/Student/StudentMasterPage.master" AutoEventWireup="true" CodeFile="frmRequestforExam.aspx.cs" Inherits="Student_frmRequestforExam" Title="Untitled Page" %>

<%@ Register assembly="AjaxControlToolkit" namespace="AjaxControlToolkit" tagprefix="cc1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        <asp:Panel ID="Panel2" runat="server" Style="left: 296px; position: absolute; top: 163px">
<cc1:CalendarExtender ID="CE2" runat="server" TargetControlID="txtExamDate">
</cc1:CalendarExtender>
            &nbsp;&nbsp;
        </asp:Panel>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <asp:Panel ID="Panel1" runat="server" Height="95px" Style="left: 450px; position: absolute;
            top: 142px" Width="543px">
<table style="left: 76px; position: absolute; top: 0px; width: 363px; height: 266px;">
<tr><td style="width: 231px; font-size: x-large; background-color: mediumblue; color: white;" colspan="2" align="center">&nbsp;Exam Request Form</td>
    <td align="center" colspan="1" style="font-size: x-large; width: 24px; color: white;
        background-color: white">
    </td>
</tr>
    <tr style="color: #000000">
        <td align="left" style="width: 129px; height: 17px">
            Examination</td>
        <td align="left" style="width: 119px; height: 17px">
            <asp:TextBox ID="txtexamtype" runat="server" Enabled="False" Height="22px" Style="left: 218px;
                top: 68px; text-align: left" Width="182px"></asp:TextBox></td>
        <td align="left" style="width: 24px; height: 17px">
        </td>
    </tr>
    <tr style="color: #000000">
        <td align="left" style="width: 129px; height: 17px">
            Examination Code</td>
        <td align="left" style="width: 119px; height: 17px">
            <asp:TextBox ID="txtexamtypeid" runat="server" Height="22px" Style="left: 218px;
                top: 68px; text-align: left;" Width="182px" Enabled="False"></asp:TextBox></td>
        <td align="left" style="width: 24px; height: 17px">
        </td>
    </tr>
    <tr style="color: #000000">
        <td align="left" style="width: 129px; height: 17px">
            Select Paper</td>
        <td align="left" style="width: 119px; height: 17px">
            <asp:DropDownList ID="ddlExamName" runat="server" Width="186px" style="left: 142px; top: 118px" Height="22px" OnSelectedIndexChanged="ddlExamName_SelectedIndexChanged" 
        ></asp:DropDownList>
        </td>
        <td align="left" style="width: 24px; height: 17px">
    <asp:RequiredFieldValidator ID="rfv3" runat="server" 
        ControlToValidate="ddlExamName" ErrorMessage="*"></asp:RequiredFieldValidator></td>
    </tr>
    <tr style="color: #000000">
        <td align="left" style="width: 129px; height: 17px">
            Select
            <br />
            Examination Date</td>
        <td align="left" style="width: 119px; height: 17px">
            <asp:TextBox ID="txtExamDate" runat="server" Height="22px" Style="left: 218px; top: 68px;
                text-align: left" Width="182px"></asp:TextBox></td>
        <td align="left" style="width: 24px; height: 17px">
        </td>
    </tr>
<tr><td style="width: 129px" align="left">
    </td><td align="left" style="width: 119px">
        &nbsp;
    </td>
    <td align="left" style="width: 24px">
    </td>
</tr>
    <tr>
        <td align="left" style="width: 129px">
        </td>
        <td align="left" style="width: 119px">
            <asp:Button ID="btnSubmit" runat="server" 
        Text="Submit" onclick="btnSubmit_Click" style="height: 26px; left: 155px; top: 234px;" /></td>
        <td align="left" style="width: 24px">
        </td>
    </tr>

<tr><td colspan="2" align="center" style="height: 30px">
    &nbsp;<asp:Label ID="lblMsg" runat="server" Width="299px" style="left: 344px; top: 191px"></asp:Label></td>
    <td align="center" colspan="1" style="width: 24px; height: 30px">
    </td>
</tr>
</table>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
        </asp:Panel>
        &nbsp; &nbsp;&nbsp;
</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
</asp:Content>

