﻿<%@ Page Language="C#" MasterPageFile="~/Student/StudentMasterPage.master" AutoEventWireup="true" CodeFile="Index.aspx.cs" Inherits="Student_Index" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        &nbsp; &nbsp;
        <asp:Panel ID="Panel1" runat="server" Height="352px" Style="left: 551px; position: absolute;
            top: 179px" Width="626px">
        <asp:Image ID="Image1" runat="server" Height="299px" Width="547px" style="left: 47px; position: absolute; top: 21px" ImageUrl="~/Images/download.png" />
        </asp:Panel>
    </center>
 
    
</asp:Content>

