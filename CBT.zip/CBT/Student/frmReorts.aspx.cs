using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Student_frmReorts : System.Web.UI.Page
{
    BALexam userobj = new BALexam();
    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            if (!IsPostBack)
            {
                string strMsg;
                userobj.UserName = Session["User"].ToString();
                userobj.getUserID(out strMsg);
                TxtUserId.Text = strMsg;
            }
        }
        catch (Exception ex)
        {
            TxtUserId.Text = ex.Message;
        }



        try
        {
            if (!IsPostBack)
            {
                string strMsg;
                userobj.uid = Convert.ToInt32(TxtUserId.Text);
                userobj.getName(out strMsg);
                txtusername.Text = strMsg;
            }
        }
        catch (Exception ex)
        {
            txtusername.Text = ex.Message;
        }





    BALexam Report = new BALexam(); 
            try
            {                  
            Report.uid = Convert.ToInt32(TxtUserId.Text);            
            GVScheduleExam.DataSource = Report.gettblStudentReport();
            GVScheduleExam.DataBind();
            if (GVScheduleExam.Rows.Count == 0)
            {
                 GVScheduleExam.Visible = false;
                 UserPanel.Visible =false; 
                 LblMsg.Text = "No Record Found";
            }
            else
            {
                GVScheduleExam.Visible = true;
                 UserPanel.Visible =true;
            }
        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
                      
    
         
           
            

    }
}
