﻿<%@ Page Language="C#" MasterPageFile="~/Student/StudentMasterPage.master" AutoEventWireup="true" CodeFile="frmViewRequests.aspx.cs" Inherits="Student_frmViewRequests" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        &nbsp;
        <asp:Panel ID="Panel1" runat="server" Height="392px" Style="left: 112px; position: relative;
            top: 8px" Width="936px">
       <asp:GridView ID="GVCheckStatus" runat="server" AutoGenerateColumns="False" 
          style="left: -22px; position: relative; top: 72px" Width="840px"  CellPadding="4" Font-Size="Large" ForeColor="Black" GridLines="None" Height="88px">
           <Columns>
             <asp:BoundField DataField="ExamRequestId" HeaderText="Exam Request Id" />       
             <asp:BoundField DataField="ExamId" HeaderText="ExamId" />    
             <asp:BoundField DataField="ExamName" HeaderText="ExamName" />
             <asp:BoundField DataField="DOR" HeaderText="Date Of Request" />
             <asp:BoundField DataField="PreferedDate" HeaderText="Exam Prefered Date" />
               <asp:BoundField DataField="CurStatus" HeaderText="Status" />
           </Columns>
           <RowStyle BackColor="#E3EAEB" />
           <FooterStyle BackColor="#FFFFC0" Font-Bold="True" ForeColor="White" />
           <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
           <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
           <HeaderStyle BackColor="#FFC080" Font-Bold="True" ForeColor="White" />
           <EditRowStyle BackColor="#7C6F57" />
           <AlternatingRowStyle BackColor="White" />
       </asp:GridView>
       <asp:Label ID="LblMsg" runat="server" style="left: 416px; position: absolute; top: 216px"></asp:Label>
        </asp:Panel>
    </center>
</asp:Content>

