﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Admin_frmExamType : System.Web.UI.Page
{
    
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OnlineWebBasedExam"].ConnectionString.ToString());
    SqlCommand cmd = new SqlCommand();

    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            gvExamType.EditIndex = -1;
            fillgrid();
        }
    }

   
  

    private void fillgrid()
    {
        SqlDataAdapter da = new SqlDataAdapter("Select ExamTypeId,ExamTypeName,Description,Date from tbl_ExamType", con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvExamType.DataSource = ds.Tables[0];
        gvExamType.DataBind();
    }
    
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            BALexam examtype = new BALexam();
            examtype.Examtypename = txtExamTypeId.Text;
            examtype.Desc = txtDescription.Text;
            string strMsg;

            int i = examtype.InsertExamType(out strMsg);
            if (i ==-1)
            {
                
                lblMsg.Text = strMsg;
            }
            else
            {
                ClearData();
                lblMsg.Text = strMsg;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }


    
    void ClearData()
    {
        try
        {
            txtExamTypeId.Text="";
            txtDescription.Text="";
            lblMsg.Text = "";
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }


    protected void tbEdit_Click(object sender, EventArgs e)
    {
        //Response.Redirect("frmEditExamType.aspx");
        HyperLink1.Visible = true;
        gvExamType.Visible = true;
        fillgrid();
    }


    protected void gvExamType_RowEditing1(object sender, GridViewEditEventArgs e)
    {
        gvExamType.EditIndex = e.NewEditIndex;
        fillgrid();
    }


    protected void gvExamType_RowDeleting1(object sender, GridViewDeleteEventArgs e)
    {

        byte ExamTypeId;
        Label l1 = (Label)(gvExamType.Rows[e.RowIndex].FindControl("EtbExamTypeId"));
        ExamTypeId = Convert.ToByte(l1.Text);
        try
        {
          
        cmd.CommandText = "delete tbl_ExamType where ExamTypeId=" + ExamTypeId;
        cmd.Connection = con;
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        

        cmd.CommandText = "update tbl_ExamType set status=0 where ExamTypeId=" + ExamTypeId;
        cmd.Connection = con;
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        cmd.CommandText = "update tbl_Exams set status=0 where ExamTypeId=" + ExamTypeId;
        cmd.Connection = con;
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }

        fillgrid();
    }
    protected void gvExamType_RowCancelingEdit1(object sender, GridViewCancelEditEventArgs e)
    {
        gvExamType.EditIndex = -1;
        fillgrid();
    }
    protected void gvExamType_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
       // int ExamTypeId = 0;
        TextBox t, t1, t2;//, t3, t4;
        Label lExamNo = (Label)gvExamType.Rows[e.RowIndex].FindControl("EtbExamTypeId");

        t = (TextBox)gvExamType.Rows[e.RowIndex].FindControl("etbExamTypeName");
        t1 = (TextBox)gvExamType.Rows[e.RowIndex].FindControl("etbDescription");
        t2 = (TextBox)gvExamType.Rows[e.RowIndex].FindControl("etbDate");
         
        cmd.CommandText = "Update tbl_ExamType set ExamTypeName='" + t.Text + "',Description='" + t1.Text + "', Date='" +t2.Text + "' where ExamTypeId=" + lExamNo.Text;
        cmd.Connection = con;
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        gvExamType.EditIndex = -1;
        fillgrid();
    }
    protected void gvExamType_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}