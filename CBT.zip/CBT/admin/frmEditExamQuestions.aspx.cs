﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmEditQuestions : System.Web.UI.Page
{
   BALQuestions question = new BALQuestions();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
                    gvExamQuestion.Visible = true;
        }
    }
    

    public void fillgrid()
    {
        if (DropDownList2.SelectedValue.ToString() != "Select")
        {
            int Id = Convert.ToInt32(DropDownList2.SelectedValue.ToString());
            gvExamQuestion.DataSource = question.gettblquestions(Id);
            gvExamQuestion.DataBind();


            if (gvExamQuestion.Rows.Count == 0)
                gvExamQuestion.Visible = false;
            else
                gvExamQuestion.Visible = true;
        }
        else
            gvExamQuestion.Visible = false;


    }



    static int id;
    protected void gvExamQuestion_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            id  = Convert.ToInt32(gvExamQuestion.Rows[e.NewEditIndex].Cells[0].Text);
            GetQuestionDetails();
            panelEdit.Visible = true;
            gvExamQuestion.Visible = false;
        }
        catch (Exception ex)
        {
            lblMsg.Visible = true;
            lblMsg.Text = ex.Message ;
        }
    }





    protected void gvExamQuestion_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvExamQuestion.EditIndex = -1;
        fillgrid();
    }

    

    protected void gvExamQuestion_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int ExamId;            
            int l1 =Convert.ToInt32(gvExamQuestion.Rows[e.RowIndex].Cells[0].Text);
            ExamId = l1;

            int j = question.getdeletetblquestion(ExamId);
            if (j > 0)
            {
                fillgrid();
                lblMsg.Text = "Record Deleted Successfully";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }



    public void GetQuestionDetails()
    {
        question.Id = id;  
        DataSet DSQues  = question.GetQuestionDetails();
        if (DSQues.Tables[0].Rows.Count > 0)
        {
            DataRow dr = DSQues.Tables[0].Rows[0];
            txtQuestionText.Text = dr[0].ToString();
            txtAns1.Text = dr[1].ToString();
            txtAns2.Text = dr[2].ToString();
            txtAns3.Text = dr[3].ToString();
            txtAns4.Text = dr[4].ToString();
            txtCorrectAnswer.Text = dr[5].ToString();
            txtMarksForQuestion.Text = dr[6].ToString();
        }
    }



   public void UpdatetblQuestion()
    {
        question.SNo = id;
        question.questiontext=txtQuestionText.Text;
        question.answer1=txtAns1.Text;
        question.answer2=txtAns2.Text;
        question.answer3=txtAns3.Text;
        question.answer4=txtAns4.Text;
        question.correctanswer=txtCorrectAnswer.Text;
        question.marksforquestion =Convert.ToInt32(txtMarksForQuestion.Text);
        question.UpdateQuestion();
    }


    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            UpdatetblQuestion();
            fillgrid();
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
            lblMsg.Visible = true;
        }

        panelEdit.Visible = false;
        gvExamQuestion.Visible = true;
    }

    
    

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {            
        fillgrid();       
    }

    protected void DropDownList2_DataBound(object sender, EventArgs e)
    {
        DropDownList2.Items.Insert(0, "Select");
      
    }
    protected void gvExamQuestion_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        gvExamQuestion.EditIndex = -1;
        fillgrid();
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
      gvExamQuestion.Visible = false;
        
    }
}
