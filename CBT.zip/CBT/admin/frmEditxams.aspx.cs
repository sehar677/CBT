﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmEditxams : System.Web.UI.Page
{
    BALexam examname = new BALexam();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            gvExamName.Visible = true;

        }
    }


    public void fillgrid()
    {

        if (DropDownList1.SelectedValue.ToString() != "Select")
        {
            examname.Examtypeid = Convert.ToInt32(DropDownList1.SelectedValue.ToString());
            gvExamName.DataSource = examname.gettblexams();
            gvExamName.DataBind();

            if (gvExamName.Rows.Count == 0)
                gvExamName.Visible = false;
            else
                gvExamName.Visible = true;

        }
        else
        {
            gvExamName.Visible = false;
        }


        
    }



    protected void gvExamName_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvExamName.EditIndex = -1;
        fillgrid();
    }



    protected void gvExamName_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int ExamId;
            Label l1 = (Label)(gvExamName.Rows[e.RowIndex].FindControl("itExamId"));
            ExamId = Convert.ToInt32(l1.Text);
            int j = examname.getdeletetblexams(ExamId);
            if (j > 0)
            {
                fillgrid();
                lblMsg.Text = "Record Deleted Successfully";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }


    protected void gvExamName_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvExamName.EditIndex = e.NewEditIndex;
        fillgrid();  
    }


    protected void gvExamName_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
            try
            {
                //int ExamId = 0;
                TextBox t, t1, t2, t3,t4;
                DropDownList d1;
                Label lExamid = (Label)gvExamName.Rows[e.RowIndex].FindControl("EtbExamId");

                t = (TextBox)gvExamName.Rows[e.RowIndex].FindControl("etbExamName");
                t1 = (TextBox)gvExamName.Rows[e.RowIndex].FindControl("etbDescription");
                t2 = (TextBox)gvExamName.Rows[e.RowIndex].FindControl("etbDOR");
                t3 = (TextBox)gvExamName.Rows[e.RowIndex].FindControl("etbNoOfQuestions");
                t4 = (TextBox)gvExamName.Rows[e.RowIndex].FindControl("etbDuration");
                d1 = (DropDownList)gvExamName.Rows[e.RowIndex].FindControl("ddletbNegativeMarking");

                int j = examname.GetUpdatetblExams(t.Text, t1.Text, t2.Text, Convert.ToInt32(t3.Text), Convert.ToInt32(t4.Text), d1.Text, Convert.ToInt32(lExamid.Text));
                if (j > 0)
                {
                    gvExamName.EditIndex = -1;
                    fillgrid();
                    lblMsg.Text = "Record updated";
                }
                else
                {
                    gvExamName.EditIndex = -1;
                }
            }
            catch (Exception ex)
            {
                lblMsg.Text = ex.Message;
            }
    }




  
  
    protected void gvExamQuestion_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        gvExamName.EditIndex = -1;
        fillgrid();
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        gvExamName.Visible = false;
        fillgrid();
    }
    protected void DropDownList1_DataBound(object sender, EventArgs e)
    {
        DropDownList1.Items.Insert(0, "Select");
    }
}
