﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmExamQuestions : System.Web.UI.Page
{
    BALQuestions question = new BALQuestions();

    public void ClearData()
    {
        txtQuestion.Text = txtAnswerA.Text = txtAnswerB.Text = txtAnswerC.Text = txtAnswerD.Text = "";
        txtCorrectAnswer.Text = "";
        txtMarksforQuestion.Text = "1";
        
    }

  

    protected void ddlExamId_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlExamId.SelectedIndex != 0)
        {
            string str = ddlExamId.SelectedItem.Text;
            string[] str1 = str.Split('-');
            ViewState["TQ"] = Convert.ToInt32(str1[1]);


            int j = Convert.ToInt32(str1[1]);
            int Id=Convert.ToInt32(ddlExamId.SelectedValue.ToString());
            object obj = question.getNQ(Id);
            int k = Convert.ToInt32(obj.ToString());
            if(j==k)
                lblMsg.Text = "All Questions are submitted.";    
            else
            lblMsg.Text = " Still " + Convert.ToString(j - k ) + " Questions Remaining.";


        }
        ClearData();
    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            int j = Convert.ToInt32(ViewState["TQ"]);
            int Id=Convert.ToInt32(ddlExamId.SelectedValue.ToString());       
            object obj=question.getNQ(Id);
            int k = Convert.ToInt32(obj.ToString());
            if(k<j)
            {
                
                if (j != 0)
                {
                    question = new BALQuestions();
                    question.examid = Convert.ToInt32(ddlExamId.SelectedValue.ToString());
                    question.questiontext = txtQuestion.Text;
                    question.answer1 = txtAnswerA.Text;
                    question.answer2 = txtAnswerB.Text;
                    question.answer3 = txtAnswerC.Text;
                    question.answer4 = txtAnswerD.Text;
                    question.correctanswer = txtCorrectAnswer.Text;
                    question.marksforquestion = Convert.ToInt32(txtMarksforQuestion.Text);
                    string strMsg;

                        int i = question.InsertQuestion(out strMsg);
                        if (i > 0)
                        {
                        ClearData();
                        lblMsg.Text = strMsg + " Still " + Convert.ToString(j - k-1) + " Questions Remaining.";
                        if (j == k+1)
                        {
                            lblMsg.Text = "All Questions are submitted. ";
                            ddlExamId.SelectedIndex = 0;
                            ClearData();
                        }
                        }
                       
                }
                else
                lblMsg.Text = "All Questions are submitted.";               

        }
        else
        lblMsg.Text = "All Questions are submitted.";

     }
     catch (Exception ex)
     {
            lblMsg.Text = ex.Message;
     }
    }


     protected void ddlExamId_DataBound(object sender, EventArgs e)
    {
        ddlExamId.Items.Insert(0, "---Select---");
        
    }

    
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        ClearData();
        lblMsg.Text = "";

    }
   

}