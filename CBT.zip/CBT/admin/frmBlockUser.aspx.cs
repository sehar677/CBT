﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class admin_frmBlockUser : System.Web.UI.Page
{
    BALexam schedule = new BALexam();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GVScheduleExam.Visible = true;
            //fillgrid();
            //Session["ETI"] = ddlExamTypeId.SelectedValue;
        }
    }


    public void fillgrid()
    {
        GVScheduleExam.DataSource = schedule.gettblActiveUsers(ddlExamTypeId.SelectedValue);
        GVScheduleExam.DataBind();
        if (GVScheduleExam.Rows.Count == 0)
            GVScheduleExam.Visible = false;
        else
            GVScheduleExam.Visible = true;
    }



   




    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OnlineWebBasedExam"].ConnectionString.ToString());
    SqlCommand cmd = new SqlCommand();
    protected void GVScheduleExam_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        int UserId = Convert.ToInt32(GVScheduleExam.Rows[e.RowIndex].Cells[0].Text);
        try
        {

            /*cmd.CommandText = "delete tbl_LoginDetails where userid=" + UserId;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            cmd.CommandText = "delete tbl_UserDetails where userid=" + UserId;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            */

            cmd.CommandText = "update tbl_LoginDetails set status=0 where userid=" + UserId;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();     

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

        fillgrid();
        LblMsg.Text = "Record Updated Successfully";
    }


    protected void ddlExamTypeId_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlExamTypeId.SelectedItem.ToString() == "Select")
        {
            Response.Write("<script>alert('Please Select')</script>");
        }
        else
        {
            Session["ETI"] = ddlExamTypeId.SelectedValue;
            fillgrid();
        }
    }


    protected void ddlExamTypeId_DataBound(object sender, EventArgs e)
    {
        ddlExamTypeId.Items.Insert(0, "Select");


    }
}



   
   
    
    
   
     
    


   

