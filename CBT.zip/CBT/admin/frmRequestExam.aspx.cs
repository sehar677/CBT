using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class admin_frmRequestExam : System.Web.UI.Page
{
   
    BALexam examdaterequest = new BALexam();

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            examdaterequest = new BALexam();
            examdaterequest.ExamReqDate = txtExamDate.Text;
            examdaterequest.Examtypeid = Convert.ToInt32(DropDownListExam.SelectedValue);
            examdaterequest.ExamId = Convert.ToInt32(DropDownListPaper.SelectedValue);
            examdaterequest.UserName = Session["User"].ToString();
            examdaterequest.CurStatus = "Not Scheduled";

            string strMsg;
            int i = examdaterequest.InsertExamRequestAll(out strMsg);
            if (i > 1)
            {
                ClearData();               
            }

            lblMsg.Text = strMsg;
               
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }



    private void ClearData()
    {
        txtExamDate.Text = "";
    }


   

    
    protected void DropDownListPaper_DataBound(object sender, EventArgs e)
    {
         DropDownListPaper.Items.Insert(0, "--Select--");
    }
  
}
