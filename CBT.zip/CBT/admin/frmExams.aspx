﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="~/admin/frmExams.aspx.cs" Inherits="Admin_frmExams" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        <asp:Panel ID="PanelNewUser" runat="server" BackColor="#0000C0" Height="480px" Style="left: -42px;
            position: relative; top: -29px; background-color: #ffffff" Width="349px">
            &nbsp;<table style="left: 1px; position: relative; top: 60px; width: 310px; height: 298px;">
<tr><td colspan="2" style="font-size: x-large; background-color: #ccff66;">Exam Details</td></tr>
    <tr>
        <td style="font-size: small; width: 110px; text-align: left;">
            Paper Name</td>
        <td style="width: 179px">
        <asp:DropDownList ID="ddlExamTypeId" runat="server" 
        Width="176px" DataSourceID="SqlDataSource1" 
                                                            
        DataTextField="ExamTypeName" DataValueField="ExamTypeId" 
        ondatabound="ddlExamTypeId_DataBound" OnSelectedIndexChanged="ddlExamTypeId_SelectedIndexChanged">
        </asp:DropDownList></td>
    </tr>
                <tr>
                    <td style="font-size: small; width: 110px; height: 26px;text-align: left">
            Negative Marking</td>
                    <td style="width: 179px; height: 26px">
            <asp:DropDownList ID="ddlYesNO" runat="server" Style="left: -1px;
                top: 2px" Width="178px">
                <asp:ListItem Selected="True">No</asp:ListItem>
                <asp:ListItem>Yes</asp:ListItem>
            </asp:DropDownList></td>
                </tr>
                <tr>
                    <td style="font-size: small; width: 110px; height: 26px;text-align: left">
                        Duration (Mins)</td>
                    <td style="width: 179px; height: 26px">
                        <asp:TextBox ID="TxtDuration" runat="server" Width="148px">30</asp:TextBox>
                        <asp:RequiredFieldValidator ID="RequiredFieldValidator4" runat="server" ControlToValidate="TxtDuration"
                            ErrorMessage="*">*</asp:RequiredFieldValidator></td>
                </tr>
<tr><td style="font-size: small; width: 110px; height: 26px;text-align: left">
    Paper Name</td><td style="width: 179px; height: 26px"><asp:TextBox ID="txtExamName" runat="server" Width="150"></asp:TextBox>
        <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" 
        ControlToValidate="txtExamName" ErrorMessage="*"></asp:RequiredFieldValidator>
    </td></tr>
<tr><td style="font-size: small; width: 110px;text-align: left">Description</td><td style="width: 179px"><asp:TextBox ID="txtDescription" runat="server" Width="150"></asp:TextBox>
    <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" 
        ControlToValidate="txtDescription" ErrorMessage="*"></asp:RequiredFieldValidator>
    </td></tr>
<tr><td style="font-size: small; width: 110px;text-align: left">No Of Questions</td><td style="width: 179px"><asp:TextBox ID="txtNoOfQues" runat="server" Width="150"></asp:TextBox>
    <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" 
        ControlToValidate="txtNoOfQues" ErrorMessage="*"></asp:RequiredFieldValidator>
    </td></tr>
<%--<tr visible="false"><td style="font-size: small">Negative Marking</td><td>
    <asp:DropDownList ID="ddlNegativemarks" runat="server" Width="150px" >
        <asp:ListItem>--Select--</asp:ListItem>
        <asp:ListItem>Yes</asp:ListItem>
        <asp:ListItem>No</asp:ListItem>
    </asp:DropDownList>
        <asp:RequiredFieldValidator ID="RequiredFieldValidator4" runat="server" 
        ControlToValidate="ddlNegativemarks" ErrorMessage="*"></asp:RequiredFieldValidator>
    </td></tr>--%>
<tr><td colspan="2" style="background-color: #ccff66">
<asp:Button ID="btnSubmit" runat="server" Text="Submit" onclick="btnSubmit_Click" 
        style="height: 26px" />
&nbsp &nbsp;&nbsp;
</td></tr>
<tr><td colspan="2">
    &nbsp;</td></tr>
<tr><td colspan="2" style="height: 21px">
<asp:Label ID="lblMsg" runat="server" Text=""></asp:Label>&nbsp;</td></tr>
</table>
            <asp:Panel ID="Panel1" runat="server" Style="left: 89px; position: absolute; top: -69px">
            <asp:SqlDataSource ID="SqlDataSource2" runat="server"></asp:SqlDataSource>
                                                        <asp:SqlDataSource ID="SqlDataSource1" runat="server" 
                                                            ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString2 %>" 
                                                            SelectCommand="SELECT [ExamTypeId], [ExamTypeName] FROM [tbl_ExamType]">
                                                        </asp:SqlDataSource>
                <br />
            </asp:Panel>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
        </asp:Panel>
</center>
</asp:Content>

