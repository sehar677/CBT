<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="frmRequestExam.aspx.cs" Inherits="admin_frmRequestExam" Title="Untitled Page" %>
<%@ Register assembly="AjaxControlToolkit" namespace="AjaxControlToolkit" tagprefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    &nbsp;<table style="left: 200px; width: 432px; position: relative; top: 24px; height: 280px;">
        <tr>
            <td align="center" colspan="2" style="font-size: x-large; width: 231px; background-color: gray; height: 29px;">
                &nbsp;Exam Preference</td>
        </tr>
        <tr>
            <td align="left" style="width: 231px">
                Select Examination</td>
            <td align="left" style="width: 257px">
                &nbsp;&nbsp;<asp:DropDownList ID="DropDownListExam" runat="server" AutoPostBack="True"
                    DataSourceID="SqlDataSourceExam" DataTextField="ExamTypeName" DataValueField="ExamTypeId"
                    Width="200px">
                </asp:DropDownList>
                <asp:RequiredFieldValidator ID="rfv2" runat="server" ControlToValidate="DropDownListExam"
                    ErrorMessage="*"></asp:RequiredFieldValidator></td>
        </tr>
        <tr>
            <td align="left" style="width: 231px; height: 24px;">
                Select Paper</td>
            <td align="left" style="width: 257px; height: 24px;">
                &nbsp;&nbsp;<asp:DropDownList ID="DropDownListPaper" runat="server" AutoPostBack="True"
                    DataSourceID="SqlDataSourcePaper" DataTextField="ExamName" DataValueField="ExamId"
                    Width="200px">
                </asp:DropDownList>
                <asp:RequiredFieldValidator ID="rfv3" runat="server" ControlToValidate="DropDownListPaper"
                    ErrorMessage="*"></asp:RequiredFieldValidator></td>
        </tr>
        <tr>
            <td align="left" style="width: 231px; height: 5px">
            </td>
            <td align="left" style="width: 257px; height: 5px">
                <br />
            </td>
        </tr>
        <tr>
            <td align="left" style="width: 231px; height: 24px">
                Select Examination Date</td>
            <td align="left" style="width: 257px; height: 24px">
                <asp:TextBox ID="txtExamDate" runat="server" Width="176px" style="left: 8px; position: relative; top: 0px" CausesValidation="True"  ></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtExamDate"
                    ErrorMessage="*" style="left: 24px; top: 0px; position: relative;" Width="24px"></asp:RequiredFieldValidator></td>
        </tr>
        <tr>
            <td align="left" colspan="" style="width: 231px; height: 24px">
                <cc1:calendarextender id="CE2" runat="server" targetcontrolid="txtExamDate" Format="dd/MM/yyyy"></cc1:calendarextender>
            </td>
            <td align="left" style="width: 257px; height: 24px">
                &nbsp;&nbsp;
                <br />
                <br />
            </td>
        </tr>
        <tr>
            <td align="center" colspan="2" style="height: 9px">
                <asp:Button ID="btnSubmit" runat="server" OnClick="btnSubmit_Click" Style="height: 26px"
                    Text="Submit" />&nbsp;
            </td>
        </tr>
        <tr>
            <td align="center" colspan="2" style="height: 35px">
                &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />
                &nbsp;&nbsp;
            </td>
        </tr>
        <tr>
            <td align="center" colspan="2" style="height: 33px">
    <asp:Label ID="lblMsg" runat="server" Style="left: 0px; position: absolute; top: 256px"
        Width="424px"></asp:Label>
                <asp:SqlDataSource ID="SqlDataSourcePaper" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString10 %>"
                    SelectCommand="SELECT [ExamId], [ExamName] FROM [tbl_Exams] WHERE ([ExamTypeId] = @ExamTypeId)">
                    <SelectParameters>
                        <asp:ControlParameter ControlID="DropDownListExam" Name="ExamTypeId" PropertyName="SelectedValue"
                            Type="Int32" />
                    </SelectParameters>
                </asp:SqlDataSource>
                <asp:SqlDataSource ID="SqlDataSourceExam" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString9 %>"
                    SelectCommand="SELECT [ExamTypeId], [ExamTypeName] FROM [tbl_ExamType]">
                </asp:SqlDataSource>
            </td>
        </tr>
    </table>
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
</asp:Content>

