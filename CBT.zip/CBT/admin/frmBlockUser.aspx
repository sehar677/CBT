﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="frmBlockUser.aspx.cs" Inherits="admin_frmBlockUser" Title="Untitled Page" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        &nbsp;</center>
    <asp:Panel ID="PanelNewUser" runat="server" BackColor="#0000C0" Height="504px" Style="left: -226px;
        position: absolute; top: -11px; background-color: #ffffff" Width="943px">
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
<asp:GridView ID="GVScheduleExam" runat="server" AutoGenerateColumns="False" 
        Visible="False"  onrowdeleting="GVScheduleExam_RowDeleting"
       style="left: 5px; position: absolute; top: 62px" Width="912px" CellPadding="4" ForeColor="#333333" GridLines="None" HorizontalAlign="Left" >
            <Columns>
                <asp:BoundField DataField="UserId" HeaderText="UserId" />
                <asp:BoundField DataField="loginid" HeaderText="Login Id" />
                <asp:BoundField DataField="fname" HeaderText="FNAME" />
                <asp:BoundField DataField="lname" HeaderText="LName" />
                <asp:BoundField DataField="address" HeaderText="Address" />
                <asp:BoundField DataField="Batch" HeaderText="Batch" />
                <asp:BoundField DataField="Password" HeaderText="Password" />
                <asp:BoundField DataField="Status" HeaderText="Status" />
                <asp:CommandField ShowDeleteButton="True" DeleteText="Block" HeaderText="Trairnee" />
            </Columns>
            <EmptyDataTemplate>
                No Data In The Table
            </EmptyDataTemplate>
    <RowStyle BackColor="Silver" ForeColor="#333333" />
    <FooterStyle BackColor="Fuchsia" Font-Bold="True" ForeColor="White" />
    <PagerStyle BackColor="#8080FF" ForeColor="#333333" HorizontalAlign="Center" />
    <SelectedRowStyle BackColor="#FFCC66" Font-Bold="True" ForeColor="Navy" />
    <HeaderStyle BackColor="Blue" Font-Bold="True" ForeColor="White" HorizontalAlign="Left" />
    <AlternatingRowStyle BackColor="White" />
        </asp:GridView>
        &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
        &nbsp;&nbsp;
        <asp:Label ID="LblMsg" runat="server" Style="left: 448px; position: absolute; top: 336px"
            Text=""></asp:Label>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <asp:Panel ID="Panel2" runat="server" Height="39px" Style="left: 2px; position: absolute;
            top: 13px; background-color: #3333ff" Width="559px">
            &nbsp;
            <asp:Label ID="Label5" runat="server" Font-Names="Calibri" Style="left: 16px; position: absolute;
                top: 8px" Text="Select Trade" Width="144px"></asp:Label>
            &nbsp;
            <asp:DropDownList ID="ddlExamTypeId" runat="server" AutoPostBack="True" DataSourceID="SqlDataSource1"
                DataTextField="Batch" DataValueField="Batch" Style="left: 293px; position: absolute;
                top: 8px" Width="181px" OnSelectedIndexChanged="ddlExamTypeId_SelectedIndexChanged" OnDataBound="ddlExamTypeId_DataBound">
            </asp:DropDownList>
        </asp:Panel>
    </asp:Panel>
    <asp:Panel ID="Panel1" runat="server" Height="72px" Style="left: 696px; position: absolute;
        top: -70px" Width="216px">
        &nbsp;
        <asp:SqlDataSource ID="SqlDataSource1" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString %>"
            SelectCommand="SELECT DISTINCT Batch FROM tbl_UserDetails where not batch='admin'">
        </asp:SqlDataSource>
    </asp:Panel>
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
</asp:Content>

