﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmExams : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    BALexam examname = new BALexam(); 

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlExamTypeId.SelectedValue.ToString() == "Select")
            {
                Response.Write("<script>alert('select Examination ?')</script>");
      
            }
            else
            {
                examname = new BALexam();
                examname.Examtypeid = Convert.ToInt32(ddlExamTypeId.SelectedValue.ToString());
                examname.Examname = txtExamName.Text;
                examname.Desc = txtDescription.Text;
                examname.Noofquestions = Convert.ToInt32(txtNoOfQues.Text);
                examname.Negativemarking = ddlYesNO.Text;
                examname.TimeDuration = Convert.ToInt32(TxtDuration.Text);
                string strMsg;

                int i = examname.InsertExamName(out strMsg);
                if (i == -1)
                {

                    lblMsg.Text = strMsg;
                }
                else
                {
                    ClearData();
                    lblMsg.Text = strMsg;

                }
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    public void ClearData()
    {
       // ddlExamTypeId.Text = 
        txtExamName.Text = txtDescription.Text = txtNoOfQues.Text ="";
    }

    
    protected void ddlExamTypeId_DataBound(object sender, EventArgs e)
    {
        ddlExamTypeId.Items.Insert(0, "Select");
    }


    protected void ddlExamTypeId_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}