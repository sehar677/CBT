﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="~/admin/frmExamQuestions.aspx.cs" Inherits="Admin_frmExamQuestions" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        <asp:Panel ID="PanelNewUser" runat="server" BackColor="#0000C0" Height="528px" Style="left: 132px;
            position: absolute; top: 50px; background-color: #ffffff" Width="488px">
            &nbsp; &nbsp;&nbsp; &nbsp;

<table style="font-size: large; left: 16px; position: absolute; top: 16px;">
<tr><td colspan="2" 
        
        style="font-family: 'Times New Roman', Times, serif; font-size: x-large; text-decoration: underline; height: 23px; background-color: #ffcc66;">
    &nbsp;Question Paper<br />
    &nbsp;
    </td></tr>
    <tr>
        <td style="font-size: medium; height: 18px">
            Select Examination</td>
        <td style="width: 292px; height: 18px">
            <asp:DropDownList ID="DropDownList1" runat="server" AutoPostBack="True" DataSourceID="SqlDataSourceExam"
                DataTextField="ExamTypeName" DataValueField="ExamTypeId" Width="264px" OnSelectedIndexChanged="DropDownList1_SelectedIndexChanged">
                <asp:ListItem Selected="True">Select</asp:ListItem>
            </asp:DropDownList>
            &nbsp;&nbsp;&nbsp;
        </td>
    </tr>
<tr><td style="font-size: medium; height: 20px;">
    Select Paper</td><td style="width: 292px; height: 20px"><asp:DropDownList ID="ddlExamId" 
        runat="server" Width="264px" AutoPostBack="True" DataSourceID="SqlDataSource1" 
        DataTextField="ExamName" DataValueField="ExamId" 
        ondatabound="ddlExamId_DataBound" onselectedindexchanged="ddlExamId_SelectedIndexChanged">
        <asp:ListItem>Select</asp:ListItem>
    </asp:DropDownList>
    &nbsp;&nbsp;&nbsp;
    </td></tr>
<tr><td style="font-size: medium; height: 40px;">Question Text</td><td style="width: 292px; height: 29px"><asp:TextBox ID="txtQuestion" runat="server" TextMode="MultiLine" Width="264px" ></asp:TextBox>
    <asp:RequiredFieldValidator ID="RequiredFieldValidator7" runat="server" ControlToValidate="txtQuestion"
        ErrorMessage="*"></asp:RequiredFieldValidator></td></tr>
<tr><td style="font-size: medium; height: 40px;">Answer A:</td><td style="width: 292px; height: 40px;"><asp:TextBox ID="txtAnswerA" runat="server" TextMode="MultiLine" Width="264px" ></asp:TextBox>
    <asp:RequiredFieldValidator ID="RequiredFieldValidator6" runat="server" ControlToValidate="txtAnswerA"
        ErrorMessage="*"></asp:RequiredFieldValidator></td></tr>
<tr><td style="font-size: medium; height: 40px;">Answer B:</td><td style="width: 292px"><asp:TextBox ID="txtAnswerB" runat="server" TextMode="MultiLine" Width="264px" ></asp:TextBox>
    <asp:RequiredFieldValidator ID="RequiredFieldValidator4" runat="server" ControlToValidate="txtAnswerB"
        ErrorMessage="*"></asp:RequiredFieldValidator></td></tr>
<tr><td style="font-size: medium; height: 40px;">Answer C:</td><td style="width: 292px"><asp:TextBox ID="txtAnswerC" runat="server" TextMode="MultiLine" Width="264px" ></asp:TextBox>
    <asp:RequiredFieldValidator ID="RequiredFieldValidator5" runat="server" ControlToValidate="txtAnswerC"
        ErrorMessage="*"></asp:RequiredFieldValidator></td></tr>
<tr><td style="font-size: medium; height: 40px;">Answer D:</td><td style="width: 292px"><asp:TextBox ID="txtAnswerD" runat="server" TextMode="MultiLine" Width="264px" ></asp:TextBox>
    <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ControlToValidate="txtAnswerD"
        ErrorMessage="*"></asp:RequiredFieldValidator></td></tr>
<tr><td style="font-size: medium; height: 40px;">Correct Answer</td><td style="width: 292px">
    <asp:TextBox ID="txtCorrectAnswer" runat="server" TextMode="MultiLine" 
        Width="264px" ></asp:TextBox>
    <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" ControlToValidate="txtCorrectAnswer"
        ErrorMessage="*"></asp:RequiredFieldValidator></td></tr>
<tr><td style="font-size: medium; height: 40px;">Marks For The Question</td><td style="width: 292px">
    <asp:TextBox ID="txtMarksforQuestion" runat="server" Width="256px" Font-Bold="True" Height="24px" >1</asp:TextBox>
    <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtMarksforQuestion"
        ErrorMessage="*"></asp:RequiredFieldValidator></td></tr>
<tr><td colspan="2" style="height: 19px; background-color: #ffcc66;">
<asp:Button ID="btnSubmit" runat="server" Text="Submit" onclick="btnSubmit_Click" 
        style="height: 26px" />

&nbsp;&nbsp; &nbsp;

</td></tr>
    <tr>
        <td colspan="2" style="height: 9px">
<asp:Label ID="lblMsg" runat="server" style="left: 648px; top: 280px" Font-Size="Medium"></asp:Label>
</td>
    </tr>
    <tr>
        <td colspan="2" style="height: 11px">
<asp:Label ID="lblError" runat="server" style="left: 648px; top: 312px" Font-Size="Medium"></asp:Label></td>
    </tr>
</table>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
        </asp:Panel>
        &nbsp;&nbsp;&nbsp;
            <asp:Panel ID="Panel1" runat="server" Style="left: 656px; position: absolute; top: -46px">
    <asp:SqlDataSource ID="SqlDataSourceExam" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString8 %>"
                SelectCommand="SELECT [ExamTypeName], [ExamTypeId] FROM [tbl_ExamType]"></asp:SqlDataSource>
    <asp:SqlDataSource ID="SqlDataSource1" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString6 %>"
        SelectCommand="SELECT [ExamId], ([ExamName]+'-'+convert(varchar(50),[NoOfQuestions])) as ExamName FROM [tbl_Exams]  WHERE ([ExamTypeId] = @ExamTypeId)">
        <SelectParameters>
            <asp:ControlParameter ControlID="DropDownList1" Name="ExamTypeId" PropertyName="SelectedValue" />
        </SelectParameters>
    </asp:SqlDataSource>
            </asp:Panel>

</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
</asp:Content>

