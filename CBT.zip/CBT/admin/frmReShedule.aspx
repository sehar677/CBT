﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="frmReShedule.aspx.cs" Inherits="admin_frmReShedule" Title="Untitled Page" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        &nbsp;</center>
    <asp:Panel ID="PanelNewUser" runat="server" BackColor="#0000C0" Height="504px" Style="left: -241px;
        position: absolute; top: -18px; background-color: #ffffff" Width="952px">
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
<asp:GridView ID="GVScheduleExam" runat="server" AutoGenerateColumns="False" 
        Visible="False" onrowediting="GVScheduleExam_RowEditing" 
       style="left: 16px; position: absolute; top: 112px" Width="912px" CellPadding="4" ForeColor="#333333" GridLines="None" OnSelectedIndexChanged="GVScheduleExam_SelectedIndexChanged">
            <Columns>
                <asp:BoundField DataField="UserId" HeaderText="UserId" />
                <asp:BoundField DataField="UserName" HeaderText="User Name" SortExpression="FName" />
                <asp:BoundField DataField="ExamId" HeaderText="ExamId" />
                <asp:BoundField DataField="ExamName" HeaderText="ExamName" />
                <asp:BoundField DataField="ExamRequestId" HeaderText="ExamRequestId" />
                <asp:BoundField DataField="DateOfSchedule" HeaderText="DateOfSchedule" />
                <asp:BoundField DataField="DateOfExam" HeaderText="DateOfExam" SortExpression="DateOfExam" />

                <asp:CommandField ShowEditButton="True" EditText="Reschedule " CausesValidation="False" />
            </Columns>
            <EmptyDataTemplate>
                No Data In The Table
            </EmptyDataTemplate>
    <RowStyle BackColor="#FFFBD6" ForeColor="#333333" />
    <FooterStyle BackColor="#990000" Font-Bold="True" ForeColor="White" />
    <PagerStyle BackColor="#FFCC66" ForeColor="#333333" HorizontalAlign="Center" />
    <SelectedRowStyle BackColor="#FFCC66" Font-Bold="True" ForeColor="Navy" />
    <HeaderStyle BackColor="#990000" Font-Bold="True" ForeColor="White" />
    <AlternatingRowStyle BackColor="White" />
        </asp:GridView>
        &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
        <table border="0" style="left: 16px; position: relative; top: -14px; width: 912px; height: 64px;">
            <tr>
                <td colspan="12" style="font-size: x-large; height: 16px; width: 484px; background-color: #990033; color: #ffffff;">
                    &nbsp; Re
                    Schedule From</td>
            </tr>
            <tr>
                <td align="left" style="width: 69px; height: 23px;" colspan="1">
                    Select Course</td>
                <td align="left" colspan="1" style="width: 137px; height: 23px;">
                    Select Paper</td>
                <td align="left" colspan="1" style="width: 151px; height: 23px;">
                    Exam ID</td>
                <td align="left" colspan="1" style="width: 6px; height: 23px">
                    &nbsp;&nbsp;
                </td>
                <td align="left" colspan="1" style="width: 151px; height: 23px">
                    &nbsp;</td>
            </tr>
            <tr>
                <td align="left" colspan="1" style="width: 69px; height: 3px;">
                    <asp:DropDownList ID="ddlExamTypeId" runat="server" DataSourceID="SqlDataSource1" OnDataBound ="ddlExamTypeId_DataBound"
                        DataTextField="ExamTypeName" DataValueField="ExamTypeId"  
                        Width="248px" AutoPostBack="True" OnSelectedIndexChanged="ddlExamTypeId_SelectedIndexChanged">
                    </asp:DropDownList></td>
                <td align="left" colspan="1" style="width: 137px; height: 3px;">
                    <asp:DropDownList ID="ddlExamId" runat="server" DataSourceID="SqlDataSource2"   DataTextField="ExamName" OnDataBound="ddlExamId_DataBound"
                        DataValueField="ExamId" Width="272px" OnSelectedIndexChanged="ddlExamId_SelectedIndexChanged" AutoPostBack="True">
                    </asp:DropDownList></td>
                <td align="left" colspan="1" style="width: 151px; height: 3px;">
                    <asp:TextBox ID="TxtExamId" runat="server" Width="136px" CausesValidation="True"  ></asp:TextBox></td>
                <td align="left" colspan="1" style="width: 6px; height: 3px">
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" ControlToValidate="TxtExamId"
                        ErrorMessage="*"></asp:RequiredFieldValidator></td>
                <td align="left" colspan="1" style="width: 151px; height: 3px">
                    &nbsp;<asp:Button ID="btnSubmit" runat="server" Height="24px" OnClick="btnSubmit_Click"
                        Text="Reshedule" style="left: 352px; top: 7px" Width="144px" /></td>
            </tr>
        </table>
        &nbsp;&nbsp;
        <asp:Label ID="LblMsg" runat="server" Style="left: 448px; position: absolute; top: 336px"
            Text=""></asp:Label>
    </asp:Panel>
    <asp:Panel ID="Panel1" runat="server" Height="72px" Style="left: 696px; position: absolute;
        top: -70px" Width="216px">
        <asp:SqlDataSource ID="SqlDataSource2" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString %>"
            SelectCommand="SELECT [ExamTypeId], [ExamId], [ExamName] FROM [tbl_Exams] WHERE ([ExamTypeId] = @ExamTypeId)">
            <SelectParameters>
                <asp:SessionParameter Name="ExamTypeId" SessionField="ETI" Type="Int32" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="SqlDataSource1" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString %>"
            SelectCommand="SELECT [ExamTypeName], [ExamTypeId] FROM [tbl_ExamType]"></asp:SqlDataSource>
    </asp:Panel>
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
</asp:Content>

