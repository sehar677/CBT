﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

public partial class Admin_AdminMasterPage : System.Web.UI.MasterPage
{
  
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
       Response.Redirect("frmExams.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmShowExamRequest.aspx");
    }
    protected void LinkButton7_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmExamQuestions.aspx");
    }
    protected void LinkButton8_Click(object sender, EventArgs e)
    {

        FormsAuthentication.SignOut();
        Session.Abandon();
        Session.Clear();
        Response.Redirect("~/Default.aspx"); 
 
    }
}
