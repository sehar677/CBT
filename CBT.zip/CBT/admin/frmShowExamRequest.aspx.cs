﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class admin_frmShowExamRequest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GVScheduleExam.Visible = true;
            fillgrid();
            Session["ETI"] = "";            
        }
    }

    BALexam schedule = new BALexam();
    public void fillgrid()
    {
        GVScheduleExam.DataSource = schedule.gettblExamRequest();
        GVScheduleExam.DataBind();
        if (GVScheduleExam.Rows.Count == 0)
            GVScheduleExam.Visible = false;
    }


    static int id;
    static string preferdate;
    static int examtypeid;
    static int ExamRequestId;
    static int ExamId;
    static string ExamName;
    protected void GVScheduleExam_RowEditing(object sender, GridViewEditEventArgs e)
    {   
            id = Convert.ToInt32(GVScheduleExam.Rows[e.NewEditIndex].Cells[0].Text);
            preferdate = GVScheduleExam.Rows[e.NewEditIndex].Cells[2].Text;
            examtypeid = Convert.ToInt32(GVScheduleExam.Rows[e.NewEditIndex].Cells[4].Text);
            ExamRequestId=Convert.ToInt32(GVScheduleExam.Rows[e.NewEditIndex].Cells[3].Text);
            ExamId = Convert.ToInt32(GVScheduleExam.Rows[e.NewEditIndex].Cells[5].Text);
            ExamName = GVScheduleExam.Rows[e.NewEditIndex].Cells[6].Text;

            Session["preferdate"] = preferdate;
            Session["uid"] = id;
            Session["examtypeid"] = examtypeid;
            Session["ExamRequestId"] = ExamRequestId;
            Session["ExamId"] = ExamId;
            Session["ExamName"] = ExamName;
            Session["UN"] = GVScheduleExam.Rows[e.NewEditIndex].Cells[1].Text;
            Response.Redirect("frmExamSchedule.aspx");        
       
    }


    BALexam objAttemptexam = new BALexam();
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {   
            string strMsg;
           
            int i=0,j;
            for (j = 0; j < GVScheduleExam.Rows.Count;j++ )
            {  
               objAttemptexam.KeyCode = txtKeyCode.Text;
               objAttemptexam.ExamAssignDate = txtAssignExamDate.Text;
               objAttemptexam.uid = Convert.ToInt32(GVScheduleExam.Rows[j].Cells[0].Text);
               objAttemptexam.ExamReqDate = GVScheduleExam.Rows[j].Cells[2].Text;
               objAttemptexam.ExamRequestId = Convert.ToInt32(GVScheduleExam.Rows[j].Cells[3].Text);
               objAttemptexam.ExamId = Convert.ToInt32(TxtExamId.Text);
               objAttemptexam.UserName = GVScheduleExam.Rows[j].Cells[1].Text;
               if (Convert.ToInt32(TxtExamId.Text) == Convert.ToInt32(GVScheduleExam.Rows[j].Cells[5].Text))
               {
                   i = objAttemptexam.InsertScheduleExamAll(out strMsg);
                   LblMsg.Text = strMsg;
               }
            }
            
               if (i > 1)
               {
                txtAssignExamDate.Text = txtKeyCode.Text = "";
               }
               else
               {
                   LblMsg.Text ="No Schedule Created";
               }
          }
          catch (Exception ex)
          {
            LblMsg.Text = ex.Message;
          }

         
         fillgrid();
         if(GVScheduleExam.Rows.Count==0)
         LblMsg.Text = "No Pending Schedule";

    }
    
   
    
    protected void ddlExamTypeId_SelectedIndexChanged(object sender, EventArgs e)
    {
       
        TxtExamId.Text = "";
        if (ddlExamTypeId.SelectedItem.ToString() == "Select")
        {
            Response.Write("<script>alert('Please Select')</script>");
        }

        else
        {
            Session["ETI"] = ddlExamTypeId.SelectedValue;
        }
    }
    
    protected void ddlExamId_DataBound(object sender, EventArgs e)
    {
        ddlExamId.Items.Insert(0, "Select");
    }
        
     
    protected void ddlExamTypeId_DataBound(object sender, EventArgs e)
    {
            ddlExamTypeId.Items.Insert(0, "Select");
            ddlExamId.Items.Insert(0, "Select");
    }


    protected void ddlExamId_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlExamId.SelectedItem.ToString() == "Select")
        {
            Response.Write("<script>alert('Please Select')</script>");
        }

        else
        {
            TxtExamId.Text = ddlExamId.SelectedValue;
        }
    }
    
}