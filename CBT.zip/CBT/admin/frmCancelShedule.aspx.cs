﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class admin_frmCancelShedule: System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GVScheduleExam.Visible = true;
            fillgrid();
            Session["ETI"] = "";            
        }
    }

    BALexam schedule = new BALexam();
    public void fillgrid()
    {
        GVScheduleExam.DataSource = schedule.gettblExamShedule();
        GVScheduleExam.DataBind();
        if (GVScheduleExam.Rows.Count == 0)
            GVScheduleExam.Visible = false;
    }


    
    protected void GVScheduleExam_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            string strMsg;
            int i = 0;
              
              objAttemptexam.uid = Convert.ToInt32(GVScheduleExam.Rows[e.NewEditIndex].Cells[0].Text);
              objAttemptexam.ExamId = Convert.ToInt32(GVScheduleExam.Rows[e.NewEditIndex].Cells[2].Text);
              objAttemptexam.ExamRequestId = Convert.ToInt32(GVScheduleExam.Rows[e.NewEditIndex].Cells[4].Text);
              i = objAttemptexam.CancelScheduleExam(out strMsg);
              LblMsg.Text = strMsg;
                      

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

        fillgrid();
        if (GVScheduleExam.Rows.Count == 0)
            LblMsg.Text = "";
             
            
       
    }


    BALexam objAttemptexam = new BALexam();
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {   
            string strMsg;           
            int i=0,j;
            for (j = 0; j < GVScheduleExam.Rows.Count;j++ )
            {                             
               objAttemptexam.uid = Convert.ToInt32(GVScheduleExam.Rows[j].Cells[0].Text);
               objAttemptexam.ExamId = Convert.ToInt32(TxtExamId.Text);
               objAttemptexam.ExamRequestId = Convert.ToInt32(GVScheduleExam.Rows[j].Cells[4].Text);
               i = objAttemptexam.CancelScheduleExamAll(out strMsg);
               LblMsg.Text = strMsg;
            }

               if (i > 1)
               {
                   TxtExamId.Text = "";
               }
               else
               {
                   LblMsg.Text = "No Schedule Cancelled";
               }
            
           

          }
          catch (Exception ex)
          {
            LblMsg.Text = ex.Message;
          }

          fillgrid();
         if(GVScheduleExam.Rows.Count==0)
         LblMsg.Text = "No Schdule List Exists";

    }
    
   
    
    protected void ddlExamTypeId_SelectedIndexChanged(object sender, EventArgs e)
    {
       
        TxtExamId.Text = "";
        if (ddlExamTypeId.SelectedItem.ToString() == "Select")
        {
            Response.Write("<script>alert('Please Select')</script>");
        }

        else
        {
            Session["ETI"] = ddlExamTypeId.SelectedValue;
        }
    }
    
    protected void ddlExamId_DataBound(object sender, EventArgs e)
    {
        ddlExamId.Items.Insert(0, "Select");
    }
        
     
    protected void ddlExamTypeId_DataBound(object sender, EventArgs e)
    {
            ddlExamTypeId.Items.Insert(0, "Select");
            ddlExamId.Items.Insert(0, "Select");
    }


    protected void ddlExamId_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlExamId.SelectedItem.ToString() == "Select")
        {
            Response.Write("<script>alert('Please Select')</script>");
        }

        else
        {
            TxtExamId.Text = ddlExamId.SelectedValue;
        }
    }

     
}