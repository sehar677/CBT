﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="frmstudentsReport.aspx.cs" Inherits="admin_frmstudentsReport" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center style="background-color: #ffffff">
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp;&nbsp;
        <asp:Panel ID="PanelNewUser" runat="server" BackColor="#0000C0" Height="480px" Style="left: 0px;
            position: absolute; top: 0px; background-color: #ffffff" Width="1016px">
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            <asp:Panel ID="Panel2" runat="server" Height="40px" Style="left: 32px; position: absolute;
                top: 24px; background-color: silver" Width="880px" BorderStyle="None">
                <asp:Label ID="Label1" runat="server" Font-Names="Calibri" Style="left: 8px; position: absolute;
                    top: 8px" Text="Type user ID" Width="96px"></asp:Label>
                <asp:TextBox ID="TxtSearch" runat="server" BorderStyle="Outset" Style="left: 112px;
                    position: absolute; top: 8px; text-align: center" CausesValidation="True"></asp:TextBox>
                <asp:Button ID="CmdSearch" runat="server" OnClick="CmdSearch_Click" Style="left: 296px;
                    position: absolute; top: 8px" Text="Search Report" Width="152px" />
                &nbsp;
            </asp:Panel>
            &nbsp;
            <asp:Panel ID="Panel4" runat="server" BorderStyle="None" Height="64px" Style="left: 32px;
                position: absolute; top: 72px; background-color: silver" Width="880px">
                <asp:Label ID="Label5" runat="server" Font-Names="Calibri" Style="left: 16px; position: absolute;
                    top: 8px" Text="Select Examination" Width="144px"></asp:Label>
            <asp:Label ID="Label3" runat="server" Font-Names="Calibri" Style="left: 176px; position: absolute;
                top: 8px" Text="Select Student" Width="112px"></asp:Label>
            <asp:Label ID="Label2" runat="server" Font-Names="Calibri" Style="left: 400px; position: absolute;
                top: 8px" Text="User Id" Width="64px"></asp:Label>
            <asp:DropDownList ID="DropDownList1" runat="server" DataSourceID="SqlDataSource3"
                DataTextField="UserName" DataValueField="UserId" Style="left: 176px; position: absolute;
                top: 32px" Width="200px" AutoPostBack="True"  OnSelectedIndexChanged="DropDownList1_SelectedIndexChanged" OnDataBound="DropDownList1_DataBound">
            </asp:DropDownList>
            <asp:TextBox ID="TxtUserId" runat="server" Style="left: 400px; position: absolute;
                top: 32px"></asp:TextBox>
                    <asp:DropDownList ID="ddlExamTypeId" runat="server" DataSourceID="SqlDataSource1"
            DataTextField="Batch" DataValueField="Batch"  
              Width="150px" style="left: 16px; position: absolute; top: 32px" AutoPostBack="True" OnDataBound="ddlExamTypeId_DataBound" OnSelectedIndexChanged="ddlExamTypeId_SelectedIndexChanged">
                    </asp:DropDownList>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="TxtSearch"
                    ErrorMessage="*" Style="left: 272px; position: absolute; top: -38px" Width="24px"></asp:RequiredFieldValidator>
            </asp:Panel>
            &nbsp;
            <asp:Panel ID="Panel1" runat="server" Style="left: -358px; position: relative; top: 336px"
                Width="208px">
            <asp:SqlDataSource ID="SqlDataSourceGrid" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString9 %>"
                SelectCommand="SELECT [UserId], [ExamId], [NoOfQuestion], [CorrectAnswers], [WrongAnswers], [Attempted], [NetScore], [TimeTaken], [ExamAttendedDate] FROM [tbl_ExamResult] WHERE ([UserId] = @UserId)">
                <SelectParameters>
                    <asp:ControlParameter ControlID="TxtUserId" Name="UserId" PropertyName="Text" Type="Int32" />
                </SelectParameters>
            </asp:SqlDataSource>
        <asp:SqlDataSource ID="SqlDataSource1" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString %>"
            SelectCommand="SELECT DISTINCT Batch FROM tbl_UserDetails where   Batch<>'Admin'"></asp:SqlDataSource>
            <asp:SqlDataSource ID="SqlDataSource3" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString9 %>"
                SelectCommand="SELECT [UserId], [FName]+[LName]  as UserName FROM [tbl_UserDetails] WHERE ([Batch] = @Batch)">
                <SelectParameters>
                    <asp:ControlParameter ControlID="ddlExamTypeId" Name="Batch" PropertyName="SelectedValue"
                        Type="String" />
                </SelectParameters>
            </asp:SqlDataSource>
            </asp:Panel>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            <asp:GridView ID="GVScheduleExam" runat="server" AutoGenerateColumns="False" Style="left: 32px;
                position: absolute; top: 144px" Width="880px" BackColor="White" BorderColor="#336666" BorderStyle="Double" BorderWidth="3px" CellPadding="4" GridLines="Horizontal">
                <Columns>
                    <asp:BoundField DataField="ExamId" HeaderText="ExamId" />
                    <asp:BoundField DataField="ExamName" HeaderText="ExamName" />
                    <asp:BoundField DataField="NoOfQuestion" HeaderText="No Of Questions" />
                    <asp:BoundField DataField="CorrectAnswers" HeaderText="CorrectAnswers" />
                    <asp:BoundField DataField="WrongAnswers" HeaderText="Wrong Answers" />
                    <asp:BoundField DataField="Attempted" HeaderText="Attempted" />
                    <asp:BoundField DataField="NetScore" HeaderText="NetScore" />
                    <asp:BoundField DataField="TimeTaken" HeaderText="TimeTaken" />
                    <asp:BoundField DataField="ExamAttendedDate" HeaderText="ExamAttendedDate" />
                </Columns>
                <EmptyDataTemplate>
                    No Data In The Table
                </EmptyDataTemplate>
                <RowStyle BackColor="White" ForeColor="#333333" />
                <FooterStyle BackColor="White" ForeColor="#333333" />
                <PagerStyle BackColor="#336666" ForeColor="White" HorizontalAlign="Center" />
                <SelectedRowStyle BackColor="#339966" Font-Bold="True" ForeColor="White" />
                <HeaderStyle BackColor="#336666" Font-Bold="True" ForeColor="White" />
            </asp:GridView>
            <asp:Label ID="LblMsg" runat="server" Style="left: 416px; position: absolute; top: 352px"
                Text=""></asp:Label>
            &nbsp; &nbsp; &nbsp;&nbsp;
        </asp:Panel>
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;
        &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp;&nbsp;
        
        
 
 
 

 
 

 
        
        
        
        
    </center>
 
</asp:Content>

