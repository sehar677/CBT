﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="frmShowExamRequest.aspx.cs" Inherits="admin_frmShowExamRequest" Title="Untitled Page" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        &nbsp;</center>
    <asp:Panel ID="PanelNewUser" runat="server" BackColor="#0000C0" Height="480px" Style="left: -227px;
        position: absolute; top: -18px; background-color: #ffffff" Width="952px">
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
<asp:GridView ID="GVScheduleExam" runat="server" AutoGenerateColumns="False" 
        Visible="False" onrowediting="GVScheduleExam_RowEditing" 
       style="left: 32px; position: absolute; top: 224px" Width="912px" BackColor="LightGoldenrodYellow" BorderColor="Tan" BorderWidth="1px" CellPadding="2" ForeColor="Black" GridLines="None">
            <Columns>
                <asp:BoundField DataField="UserId" HeaderText="UserId" />
                <asp:BoundField DataField="UserName" HeaderText="User Name" SortExpression="FName" />
                <asp:BoundField DataField="PreferedDate" HeaderText="Exam Preferable Date" />
                <asp:BoundField DataField="ExamRequestId" HeaderText="ExamRequestId" />
                <asp:BoundField DataField="ExamTypeId" HeaderText="ExamTypeId" />
                <asp:BoundField DataField="ExamId" HeaderText="Exam ID" />
                <asp:BoundField DataField="ExamName" HeaderText="Exam Name" SortExpression="ExamName" />
                <asp:BoundField DataField="CurStatus" HeaderText="Status" SortExpression="CurStatus" />

                <asp:CommandField ShowEditButton="True" EditText="Schedule Exam" CausesValidation="False" />
            </Columns>
            <EmptyDataTemplate>
                No Data In The Table
            </EmptyDataTemplate>
    <FooterStyle BackColor="Tan" />
    <PagerStyle BackColor="PaleGoldenrod" ForeColor="DarkSlateBlue" HorizontalAlign="Center" />
    <SelectedRowStyle BackColor="DarkSlateBlue" ForeColor="GhostWhite" />
    <HeaderStyle BackColor="Tan" Font-Bold="True" />
    <AlternatingRowStyle BackColor="PaleGoldenrod" />
        </asp:GridView>
        &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
        <table border="0" style="left: 32px; position: absolute; top: 16px; width: 912px; height: 80px;">
            <tr>
                <td colspan="15" style="font-size: x-large; width: 461px; height: 16px">
        <asp:SqlDataSource ID="SqlDataSource2" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString %>"
            SelectCommand="SELECT [ExamTypeId], [ExamId], [ExamName] FROM [tbl_Exams] WHERE ([ExamTypeId] = @ExamTypeId)">
            <SelectParameters>
                <asp:SessionParameter Name="ExamTypeId" SessionField="ETI" Type="Int32" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="SqlDataSource1" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString %>"
            SelectCommand="SELECT [ExamTypeName], [ExamTypeId] FROM [tbl_ExamType]"></asp:SqlDataSource>
                    <cc1:CalendarExtender ID="CE1" runat="server" TargetControlID="txtAssignExamDate" Format='dd/MM/yyyy'>
                    </cc1:CalendarExtender>
                </td>
            </tr>
            <tr>
                <td colspan="15" style="font-size: x-large; height: 16px; width: 461px; background-color: #cc9966;">
                    Create &nbsp;Schedule</td>
            </tr>
            <tr>
                <td align="left" style="width: 105px; height: 23px;" colspan="2">
                    Select Course</td>
                <td align="left" colspan="1" style="width: 117px; height: 23px;">
                    Select Paper</td>
                <td align="left" colspan="1" style="width: 151px; height: 23px;">
                    Exam ID</td>
                <td align="left" colspan="1" style="width: 151px; height: 23px">
                    &nbsp;</td>
                <td align="left" colspan="1" style="width: 117px; height: 23px;">
                    Date Of Assign</td>
                <td align="left" colspan="1" style="width: 117px; height: 23px">
                </td>
                <td align="left" colspan="1" style="width: 116px; height: 23px;">
                    Key Code</td>
                <td align="left" colspan="1" style="width: 116px; height: 23px">
                    &nbsp; &nbsp;
                </td>
                <td align="left" colspan="1" style="width: 116px; height: 23px">
                </td>
            </tr>
            <tr>
                <td align="left" colspan="2" style="width: 105px; height: 3px;">
                    <asp:DropDownList ID="ddlExamTypeId" runat="server" DataSourceID="SqlDataSource1" OnDataBound ="ddlExamTypeId_DataBound"
                        DataTextField="ExamTypeName" DataValueField="ExamTypeId"  
                        Width="168px" AutoPostBack="True" OnSelectedIndexChanged="ddlExamTypeId_SelectedIndexChanged">
                    </asp:DropDownList></td>
                <td align="left" colspan="1" style="width: 117px; height: 3px;">
                    <asp:DropDownList ID="ddlExamId" runat="server" DataSourceID="SqlDataSource2"   DataTextField="ExamName" OnDataBound="ddlExamId_DataBound"
                        DataValueField="ExamId" Width="152px" OnSelectedIndexChanged="ddlExamId_SelectedIndexChanged" AutoPostBack="True">
                    </asp:DropDownList></td>
                <td align="left" colspan="1" style="width: 151px; height: 3px;">
                    <asp:TextBox ID="TxtExamId" runat="server" Width="136px" CausesValidation="True"  ></asp:TextBox></td>
                <td align="left" colspan="1" style="width: 151px; height: 3px">
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" ControlToValidate="TxtExamId"
                        ErrorMessage="*"></asp:RequiredFieldValidator></td>
                <td align="left" colspan="1" style="width: 117px; height: 3px;">
                    <asp:TextBox ID="txtAssignExamDate" runat="server" Width="104px" CausesValidation="True"></asp:TextBox></td>
                <td align="left" colspan="1" style="width: 117px; height: 3px">
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtAssignExamDate"
                        ErrorMessage="*"></asp:RequiredFieldValidator></td>
                <td align="left" colspan="1" style="width: 116px; height: 3px;">
                    <asp:TextBox ID="txtKeyCode" runat="server" Width="112px" CausesValidation="True"></asp:TextBox></td>
                <td align="left" colspan="1" style="width: 116px; height: 3px">
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ControlToValidate="txtKeyCode"
                        ErrorMessage="*" TabIndex="1"></asp:RequiredFieldValidator></td>
                <td align="left" colspan="1" style="width: 116px; height: 3px">
                    <asp:Button ID="btnSubmit" runat="server" Height="24px" OnClick="btnSubmit_Click"
                        Text="Submit" style="left: 352px; top: 7px" Width="112px" /></td>
            </tr>
            <tr>
                <td colspan="10" style="width: 117px; height: 1px">
                    &nbsp; &nbsp;&nbsp;&nbsp;
        <asp:Label ID="LblMsg" runat="server" Style="left: 456px; position: absolute; top: 200px"
            Text=""></asp:Label>
                </td>
            </tr>
        </table>
        &nbsp;&nbsp;
    </asp:Panel>
</asp:Content>

