﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using OnlineWebBasedExam;

public partial class admin_frmstudentsReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["ETI"] = "";              
    }


    BALexam Report = new BALexam(); 
    public void fillgrid()
    {
       try
        {                  
            Report.uid = Convert.ToInt32(TxtUserId.Text);            
            GVScheduleExam.DataSource = Report.gettblStudentReport();
            GVScheduleExam.DataBind();
            if (GVScheduleExam.Rows.Count == 0)
            {
                GVScheduleExam.Visible = false;
                 LblMsg.Text = "No Record Found";
            }
            else
                GVScheduleExam.Visible = true;
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
                      
    }


    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TxtUserId.Text = DropDownList1.SelectedValue.ToString();
        fillgrid();
    }
    protected void DropDownList1_DataBound(object sender, EventArgs e)
    {
        DropDownList1.Items.Insert(0, "--Select--");
        TxtUserId.Text = "";
        if (TxtSearch.Text.Length == 0)
        {
            GVScheduleExam.Visible = false;
            LblMsg.Text = "";
        }
    }

    protected void ddlExamTypeId_DataBound(object sender, EventArgs e)
    {
        ddlExamTypeId.Items.Insert(0, "--Select--");
    }
    protected void ddlExamTypeId_SelectedIndexChanged(object sender, EventArgs e)
    {
        TxtSearch.Text = "";
    }


    protected void CmdSearch_Click(object sender, EventArgs e)
    {

        try
        {

            if (TxtSearch.Text.Length >0)
            {
                LblMsg.Text = "";
                Report.uid = Convert.ToInt32(TxtSearch.Text);
                GVScheduleExam.DataSource = Report.gettblStudentReport();
                GVScheduleExam.DataBind();
                if (GVScheduleExam.Rows.Count == 0)
                {
                    GVScheduleExam.Visible = false;
                    LblMsg.Text = "No Record Found";
                }
                else
                    GVScheduleExam.Visible = true;
            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }

   
}
