﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="~/admin/frmViewUser.aspx.cs" Inherits="Admin_frmViewUser" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        <asp:Panel ID="PanelNewUser" runat="server" BackColor="#0000C0" Height="480px" Style="left: -154px;
            position: absolute; top: -17px; background-color: #ffffff" Width="864px">
            <br />
            &nbsp;
            <asp:Panel ID="Panel2" runat="server" Style="left: 532px; position: absolute; top: -51px">
            <asp:SqlDataSource ID="SqlDataSource1" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString %>"
                SelectCommand="SELECT DISTINCT Batch FROM tbl_UserDetails where not batch='admin'" >
            </asp:SqlDataSource>
            <asp:SqlDataSource ID="SqlDataSource2" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString6 %>"
                SelectCommand="SELECT tbl_UserDetails.UserId, loginId,[FName], [LName], [ContactNo], [Address], [Batch] ,[Password] FROM [tbl_UserDetails] ,[tbl_LoginDetails] WHERE ([Batch] = @Batch) and tbl_LoginDetails.userid=tbl_UserDetails.userid">
                <SelectParameters>
                    <asp:ControlParameter ControlID="ddlExamTypeId" Name="Batch" PropertyName="SelectedValue"
                        Type="String" DefaultValue="" />
                </SelectParameters>
            </asp:SqlDataSource>
            </asp:Panel>
            &nbsp;
            <asp:Panel ID="Panel1" runat="server" Height="43px" Style="left: 11px; position: absolute;
                top: 11px; background-color: #336666" Width="350px">
            <asp:DropDownList ID="ddlExamTypeId" runat="server" AutoPostBack="True" DataSourceID="SqlDataSource1"
                DataTextField="Batch" DataValueField="Batch" Style="left: 165px; position: absolute;
                top: 9px" Width="181px">
            </asp:DropDownList>
            <asp:Label ID="Label5" runat="server" Font-Names="Calibri" Style="left: 16px; position: absolute;
                top: 8px" Text="Select Examination" Width="144px"></asp:Label>
            </asp:Panel>
            &nbsp;
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" CellPadding="4"
                DataSourceID="SqlDataSource2" ForeColor="#333333" GridLines="None" Style="left: 13px;
                position: absolute; top: 63px" Width="849px" OnRowDataBound="GridView1_RowDataBound">
                <RowStyle BackColor="#E3EAEB" />
                <Columns>
                    <asp:BoundField DataField="UserId" HeaderText="UserId" InsertVisible="False" ReadOnly="True"
                        SortExpression="UserId" />
                    <asp:BoundField DataField="loginId" HeaderText="loginId" SortExpression="loginId" />
                    <asp:BoundField DataField="FName" HeaderText="FName" SortExpression="FName" />
                    <asp:BoundField DataField="LName" HeaderText="LName" SortExpression="LName" />
                    <asp:BoundField DataField="ContactNo" HeaderText="ContactNo" SortExpression="ContactNo" />
                    <asp:BoundField DataField="Address" HeaderText="Address" SortExpression="Address" />
                    <asp:BoundField DataField="Batch" HeaderText="Batch" SortExpression="Batch" />
                    <asp:BoundField DataField="Password" HeaderText="Password" SortExpression="Password" />
          
          
                </Columns>
                <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                <EditRowStyle BackColor="#7C6F57" />
                <AlternatingRowStyle BackColor="White" />
            </asp:GridView>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br />
            &nbsp;<br />
            <br />
            <br />
            <br />
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;

 
 

            
            
            
            
        </asp:Panel>
        &nbsp;&nbsp;&nbsp;&nbsp;
    </center>
</asp:Content>

