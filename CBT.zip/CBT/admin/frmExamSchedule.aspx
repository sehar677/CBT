﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="~/admin/frmExamSchedule.aspx.cs" Inherits="admin_ExamSchedule" Title="Untitled Page" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        <asp:Panel ID="PanelNewUser" runat="server" BackColor="#0000C0" Height="480px" Style="left: 0px;
            position: absolute; top: -6px; background-color: #ffffff" Width="840px">
            &nbsp;
<table border="1" style="left: 240px; position: absolute; top: 56px; width: 416px; height: 328px;">
<tr><td style="font-size: x-large; width: 434px; background-color: #cccc66;" colspan="3">Exam Schedule</td></tr>
    <tr>
        <td align="left" style="width: 115px">
    Exam Name<br />
            <br />
            Exam ID<br />
            <br />
            Key Code<br />
            <br />
            Date Of Assign</td>
        <td style="width: 188px">
            <asp:TextBox ID="TxtExamName" runat="server" Height="24px" Width="224px"></asp:TextBox><br />
            <br />
            <asp:TextBox ID="TxtExamId" runat="server" Width="224px" Height="24px"></asp:TextBox><br />
            <br />
            <asp:TextBox ID="txtKeyCode" runat="server" Height="24px" Width="224px"></asp:TextBox>&nbsp;<br />
            <br />
            <asp:TextBox ID="txtAssignExamDate" runat ="server" Width="224px" CausesValidation="True" Height="24px" ></asp:TextBox></td>
    </tr>
<tr><td colspan="2" style="background-color: #cccc66">
    <asp:Button ID="btnSubmit" runat="server" Text="Submit" 
        onclick="btnSubmit_Click" Height="32px" Width="136px" />&nbsp;<br />
</td></tr>
</table>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp;&nbsp;
            <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtKeyCode"
                ErrorMessage="*" Style="left: 168px; position: relative; top: 240px" Width="16px"></asp:RequiredFieldValidator><asp:RequiredFieldValidator
                    ID="RequiredFieldValidator2" runat="server" ControlToValidate="txtAssignExamDate"
                    ErrorMessage="*" Style="left: 152px; position: relative; top: 288px" Width="16px"></asp:RequiredFieldValidator><cc1:CalendarExtender ID="CE1" runat="server" TargetControlID="txtAssignExamDate" Format="dd/MM/yyyy">
</cc1:CalendarExtender>
        <asp:LinkButton ID="LBScheduleExam" runat="server" onclick="LB_Click" style="left: 16px; position: relative; top: 456px" Width="152px" CausesValidation="False">Go To 
        Schedule Exam</asp:LinkButton>
            &nbsp;
            <br />
            <br />
<asp:Label ID="LblMsg" runat="server" Text="" style="left: 16px; position: relative; top: 344px"></asp:Label><br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
        </asp:Panel>
        &nbsp; &nbsp;&nbsp;
</center>
</asp:Content>

