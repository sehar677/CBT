﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Mail;

public partial class admin_ExamSchedule : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
                int examtypeid = Convert.ToInt32(Session["examtypeid"].ToString());
                int ExamId = Convert.ToInt32(Session["ExamId"].ToString());
                string ExamName =  Session["ExamName"].ToString();
                TxtExamName.Text = ExamName;
                TxtExamId.Text = Convert.ToString(ExamId);

        }
    }
    BALexam objAttemptexam = new BALexam();

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
            try
            {
                objAttemptexam.KeyCode = txtKeyCode.Text;
                objAttemptexam.ExamAssignDate = txtAssignExamDate.Text;
                objAttemptexam.ExamReqDate =  Session["preferdate"].ToString();
                objAttemptexam.uid = Convert.ToInt32(Session["uid"].ToString());                
                objAttemptexam.ExamId = Convert.ToInt32(Session["ExamId"].ToString());
                objAttemptexam.ExamRequestId = Convert.ToInt32(Session["ExamRequestId"].ToString());
                objAttemptexam.UserName = Session["UN"].ToString();            
         

                string strMsg;
                //SendMails();
                int i = objAttemptexam.InsertScheduleExam(out strMsg);
                if (i > 1)
                {
                    ClearData();
                    LblMsg.Text = strMsg;
                }
                else
                    LblMsg.Text = strMsg;
            }
            catch (Exception ex)
            {
                LblMsg.Text = ex.Message;
            }
    }


   /* 
    void SendMails()
    {
        MailMessage objMail = new MailMessage();
        objMail.From = "OnLineWebExamination.Com";
        objMail.To = "Localhost";
        objMail.Subject = "OnLineExam Schedule.";
        objMail.Body = "Your Key                 : " + txtKeyCode.Text + "" + "\n" +
                       "Your ExamId              : " + Convert.ToInt32(ddlExamIdNotAttempted.SelectedValue) + "" + "\n" +
                       "Your ExamDate            : " + txtAssignExamDate.Text;

        SmtpMail.SmtpServer = "LocalHost";
        SmtpMail.Send(objMail);
        Page.RegisterClientScriptBlock("Dhanush", "<script>alert('Key Send to Student Successfully...')</script>");
    }
    */

    private void ClearData()
    {
        txtAssignExamDate.Text = txtKeyCode.Text = "";
    }
    protected void ddlExamIdAttempted_DataBound(object sender, EventArgs e)
    {
        //ddlExamIdNotAttempted.Items.Insert(0, "--Select--");
    }
    protected void ddlExamIdNotAttempted_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void LB_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmShowExamRequest.aspx");
    }
}