﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="~/admin/frmEditxams.aspx.cs" Inherits="Admin_frmEditxams" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        <asp:Panel ID="PanelNewUser" runat="server" BackColor="Lime" Height="472px" Style="left: 3px;
            top: -31px; background-color: #ffffff; position: absolute;" Width="808px">
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                <asp:Panel ID="Panel3" runat="server" Style="left: 8px; position: absolute; top: 8px;
                    background-color: #336699" Width="792px">
                    <asp:Label ID="Label1" runat="server" Style="left: 0px; position: absolute; top: 8px"
                        Text="Select Examination" Width="128px"></asp:Label>
                    <asp:DropDownList ID="DropDownList1" runat="server" AutoPostBack="True" DataSourceID="SqlDataExam"
                        DataTextField="ExamTypeName" DataValueField="ExamTypeId" OnDataBound="DropDownList1_DataBound"
                        OnSelectedIndexChanged="DropDownList1_SelectedIndexChanged" Style="left: 136px;
                        position: absolute; top: 8px" Width="208px">
                    </asp:DropDownList>
                    <br />
                    <br />
                </asp:Panel>
    
    <asp:GridView ID="gvExamName" runat="server" AutoGenerateColumns="False" 
        CellPadding="4" ForeColor="#333333" GridLines="None" Visible="False" 
        onrowcancelingedit="gvExamName_RowCancelingEdit" 
        onrowediting="gvExamName_RowEditing" 
        onrowdeleting="gvExamName_RowDeleting" onrowupdating="gvExamName_RowUpdating" style="left: 8px; top: 72px; position: absolute;" Height="96px" Width="792px" Font-Size="Small">
        <FooterStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" />
        <RowStyle BackColor="#F7F6F3" ForeColor="#333333" />
    <Columns>
    
            <asp:TemplateField HeaderText="Exam Id">
              <ItemTemplate>
                <asp:Label  ID="itExamId" runat="server" Text='<%# Eval("ExamId") %>' ></asp:Label>
              </ItemTemplate>
              <EditItemTemplate>
              <asp:Label  ID="EtbExamId" runat="server" Text='<%# Eval("ExamId")%>' ></asp:Label>
              </EditItemTemplate>            
            </asp:TemplateField>
    
            <asp:TemplateField HeaderText="Exam Name">
              <ItemTemplate>
                <%# Eval("ExamName")%>
              </ItemTemplate>
              <EditItemTemplate>
              <asp:TextBox ID="etbExamName" runat="server" Text='<%# Eval("ExamName")%>' ></asp:TextBox>
              <asp:RequiredFieldValidator ID="rfv1" runat="server" ControlToValidate="etbExamName" ErrorMessage="*">
              </asp:RequiredFieldValidator>
              </EditItemTemplate>
            </asp:TemplateField>
            
             <asp:TemplateField HeaderText="Description">
              <ItemTemplate>
                <%# Eval("Description")%>
              </ItemTemplate>
              <EditItemTemplate>
              <asp:TextBox ID="etbDescription" runat="server" TextMode="MultiLine" Text='<%# Eval("Description")%>' ></asp:TextBox>
              <asp:RequiredFieldValidator ID="rfv2" runat="server" ControlToValidate="etbDescription" ErrorMessage="*"></asp:RequiredFieldValidator>
              </EditItemTemplate>
            </asp:TemplateField>
            
            <asp:TemplateField HeaderText="Date">
              <ItemTemplate>
                <%# Eval("DOR")%>
              </ItemTemplate>
              <EditItemTemplate>
              <asp:TextBox ID="etbDOR" runat="server" Text='<%# Eval("DOR")%>' ></asp:TextBox>
              <asp:RequiredFieldValidator ID="rfv3" runat="server" ControlToValidate="etbDOR" ErrorMessage="*"></asp:RequiredFieldValidator>
              </EditItemTemplate>
            </asp:TemplateField>
            
            <asp:TemplateField HeaderText="No Of Questions">
              <ItemTemplate>
                <%# Eval("NoOfQuestions")%>
              </ItemTemplate>
              <EditItemTemplate>
              <asp:TextBox ID="etbNoOfQuestions" runat="server"  Text='<%# Eval("NoOfQuestions")%>' ></asp:TextBox>
              <asp:RequiredFieldValidator ID="rfv4" runat="server" ControlToValidate="etbNoOfQuestions" ErrorMessage="*"></asp:RequiredFieldValidator>
              </EditItemTemplate>
            </asp:TemplateField>
            
            <asp:TemplateField HeaderText="NegativeMarking">
              <ItemTemplate>
                <%# Eval("NegativeMarking")%>
              </ItemTemplate>
              <EditItemTemplate>        
               <asp:DropDownList ID="ddletbNegativeMarking" CausesValidation="false" runat="server" Width="150" >
                      <asp:ListItem>No</asp:ListItem>
                      <asp:ListItem>Yes</asp:ListItem>
              </asp:DropDownList>
              <asp:RequiredFieldValidator ID="rfv5" runat="server" ControlToValidate="ddletbNegativeMarking" ErrorMessage="*"></asp:RequiredFieldValidator>
              </EditItemTemplate>
            </asp:TemplateField>
            
    <asp:TemplateField HeaderText="Duration">
              <ItemTemplate>
                <%# Eval("Duration")%>
              </ItemTemplate>
              <EditItemTemplate>
              <asp:TextBox ID="etbDuration" runat="server"  Text='<%# Eval("Duration")%>' ></asp:TextBox>
              <asp:RequiredFieldValidator ID="rfv6" runat="server" ControlToValidate="etbDuration" ErrorMessage="*"></asp:RequiredFieldValidator>
              </EditItemTemplate>
            </asp:TemplateField>
           
            <asp:CommandField ShowEditButton="True" ShowDeleteButton="True" CausesValidation="False" />
    </Columns>

        <PagerStyle BackColor="#284775" ForeColor="White" HorizontalAlign="Center" />
        <SelectedRowStyle BackColor="#E2DED6" Font-Bold="True" ForeColor="#333333" />
        <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" />
        <EditRowStyle BackColor="#999999" />
        <AlternatingRowStyle BackColor="White" ForeColor="#284775" />

    </asp:GridView>
                        <asp:Label ID="lblMsg" runat="server" style="left: 366px; position: absolute; top: 17px" ForeColor="White"></asp:Label>
        </asp:Panel>
        &nbsp; &nbsp; &nbsp;
</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
            <asp:Panel ID="Panel2" runat="server" Height="1px" Style="left: 648px; position: absolute;
                top: 24px" Width="192px">
    
    <asp:SqlDataSource ID="SqlDataExam" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString9 %>"
                    SelectCommand="SELECT [ExamTypeId], [ExamTypeName] FROM [tbl_ExamType]"></asp:SqlDataSource>
                &nbsp;</asp:Panel>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
</asp:Content>

