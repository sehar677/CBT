﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmEditRequest : System.Web.UI.Page
{
    BALexam schedule = new BALexam();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GVScheduleExam.Visible = true;
            fillgrid();
            Session["ETI"] = "";
        }
    }



    public void fillgrid()
    {
        GVScheduleExam.DataSource = schedule.gettblExamRequest();
        GVScheduleExam.DataBind();
        if (GVScheduleExam.Rows.Count == 0)
            GVScheduleExam.Visible = false;
    }




    BALexam objAttemptexam = new BALexam();
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string strMsg;
            int i = 0;
            objAttemptexam.Examtypeid = Convert.ToInt32(DropDownList1.SelectedValue);
            objAttemptexam.ExamId = Convert.ToInt32(TxtExamId.Text);
            i = objAttemptexam.CancelExamRequestAll(out strMsg);
            LblMsg.Text = strMsg;
            if (i > 0)
                fillgrid();

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }





    protected void GVScheduleExam_RowEditing(object sender, GridViewEditEventArgs e)
    {

        try
        {
            string strMsg;
            objAttemptexam.ExamRequestId = Convert.ToInt32(GVScheduleExam.Rows[e.NewEditIndex].Cells[3].Text);
            objAttemptexam.CancelExamRequest(out strMsg);
            LblMsg.Text = strMsg;
            fillgrid();
            if (GVScheduleExam.Rows.Count == 0)
                GVScheduleExam.Visible = false;
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList2.SelectedItem.ToString() != "Select")
            TxtExamId.Text = DropDownList2.SelectedValue;
        else
            TxtExamId.Text = "";
    }

    protected void DropDownList2_DataBound(object sender, EventArgs e)
    {
        DropDownList2.Items.Insert(0, "Select");

    }
}
