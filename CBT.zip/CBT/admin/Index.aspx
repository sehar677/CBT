﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="~/admin/Index.aspx.cs" Inherits="Admin_Index" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        <asp:Panel ID="PanelNewUser" runat="server" BackColor="#0000C0" Height="480px" Style="left: 175px;
            position: absolute; top: -30px; background-color: #ffffff" Width="840px">
            <br />
            <br />
            <br />
            <asp:Label ID="Label2" runat="server" Height="1px" Style="font-size: 20pt; left: 295px;
                font-family: Algerian; position: absolute; top: 16px" Text="Control Panel" Width="232px"></asp:Label>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <asp:Label ID="Label1" runat="server" Height="15px" Style="left: 14px; position: absolute; top: 454px; font: messagebox;" Text="ManagePapers" Width="12px"></asp:Label>
            &nbsp;&nbsp;<br />
            <asp:Image ID="Image6" runat="server" Height="52px" ImageUrl="~/Images/c7.png" Style="left: 22px;
                position: absolute; top: 388px" Width="56px" />
            <asp:Label ID="Label7" runat="server" Height="1px" Style="left: 755px; font: messagebox;
                position: absolute; top: 443px" Text="Manage Questions" Width="51px"></asp:Label>
            <br />
            <asp:Image ID="Image4" runat="server" Height="52px" ImageUrl="~/Images/c4.png" Style="left: 752px;
                position: absolute; top: 389px" Width="56px" />
            <br />
            <asp:Image ID="Image2" runat="server" Height="52px" ImageUrl="~/Images/c1.png" Style="left: 473px;
                position: absolute; top: 388px" Width="56px" />
            <asp:Label ID="Label6" runat="server" Height="1px" Style="left: 614px; font: messagebox;
                position: absolute; top: 444px" Text="Control Panel" Width="51px"></asp:Label>
            <asp:Label ID="Label5" runat="server" Height="1px" Style="left: 477px; font: messagebox;
                position: absolute; top: 443px" Text="Manage Shedule" Width="51px"></asp:Label>
            <br />
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
            <asp:Image ID="Image1" runat="server" Height="52px" ImageUrl="~/Images/c2.png" Style="left: 173px;
                position: absolute; top: 386px" Width="56px" />
            <asp:Label ID="Label3" runat="server" Height="1px" Style="left: 175px; font: messagebox;
                position: absolute; top: 445px" Text="View Trainees" Width="51px"></asp:Label>
            <asp:Image ID="Image3" runat="server" Height="52px" ImageUrl="~/Images/c3.png" Style="left: 328px;
                position: absolute; top: 389px" Width="56px" />
            <asp:Image ID="Image5" runat="server" Height="52px" ImageUrl="~/Images/c5.jpg" Style="left: 615px;
                position: absolute; top: 396px" Width="56px" />
            <asp:Label ID="Label4" runat="server" Height="1px" Style="left: 337px; font: messagebox;
                position: absolute; top: 444px" Text="Control Panel" Width="51px"></asp:Label>
        </asp:Panel>
        &nbsp;</center>
</asp:Content>

