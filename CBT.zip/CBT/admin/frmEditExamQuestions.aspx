﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true"
    CodeFile="~/admin/frmEditExamQuestions.aspx.cs" Inherits="Admin_frmEditQuestions"
    Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" runat="Server">
    <center>
        &nbsp;
        <asp:Panel ID="Panel2" runat="server" Style="left: 617px; position: absolute; top: -22px">
            &nbsp;
            <asp:SqlDataSource ID="SqlDataExam" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString9 %>"
                SelectCommand="SELECT [ExamTypeName], [ExamTypeId] FROM [tbl_ExamType]"></asp:SqlDataSource>
            <asp:SqlDataSource ID="SqlDataPaper" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString9 %>"
                SelectCommand="SELECT [ExamName], [ExamId] FROM [tbl_Exams] WHERE ([ExamTypeId] = @ExamTypeId)">
                <SelectParameters>
                    <asp:ControlParameter ControlID="DropDownList1" Name="ExamTypeId" PropertyName="SelectedValue"
                        Type="Int32" />
                </SelectParameters>
            </asp:SqlDataSource>
        </asp:Panel>
        &nbsp; &nbsp; &nbsp; &nbsp;
        <asp:Panel ID="Panel1" runat="server" Height="228px" Style="left: -238px; position: absolute;
            top: -14px" Width="896px">
            <asp:Panel ID="Panel4" runat="server" Height="43px" Style="left: 16px; position: absolute;
                top: 16px; background-color: #003399" Width="848px">
            <asp:Label ID="Label2" runat="server" Height="23px" Style="left: 5px; position: absolute;
                top: 10px; color: #ffffff;" Text="Select Examination"></asp:Label>
            <asp:Label ID="Label1" runat="server" Height="24px" Style="left: 376px; position: absolute;
                top: 8px; color: #ffffff;" Text="Select Paper" Width="120px"></asp:Label>
                <asp:DropDownList ID="DropDownList1" runat="server" AutoPostBack="True" DataSourceID="SqlDataExam"
                    DataTextField="ExamTypeName" DataValueField="ExamTypeId" Style="left: 122px;
                    position: absolute; top: 11px" Width="240px" OnSelectedIndexChanged="DropDownList1_SelectedIndexChanged">
                </asp:DropDownList>
                <asp:DropDownList ID="DropDownList2" runat="server" AutoPostBack="True" DataSourceID="SqlDataPaper"
                    DataTextField="ExamName" DataValueField="ExamId" OnDataBound="DropDownList2_DataBound"
                    OnSelectedIndexChanged="DropDownList2_SelectedIndexChanged" Style="left: 512px;
                    position: absolute; top: 8px" Width="288px">
                </asp:DropDownList>
            </asp:Panel>
            <br />
            &nbsp;<br />
            &nbsp;<br />
            &nbsp;
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <asp:Panel ID="Panel3" runat="server" Style="left: 16px; position: absolute; top: 72px" Width="848px">
                <br />
                <br />
                <asp:GridView ID="gvExamQuestion" runat="server" AutoGenerateColumns="False" BackColor="White"
                    BorderColor="#3366CC" BorderStyle="None" BorderWidth="1px" CellPadding="4" Height="48px"
                    OnRowCancelingEdit="gvExamQuestion_RowCancelingEdit" OnRowDeleting="gvExamQuestion_RowDeleting"
                    OnRowEditing="gvExamQuestion_RowEditing" Style="left: 6px; position: absolute;
                    top: 5px" Visible="False" Width="840px" OnRowUpdating="gvExamQuestion_RowUpdating">
                    <RowStyle BackColor="White" ForeColor="#003399" />
                    <Columns>
                        <asp:BoundField DataField="QuestionSNo" HeaderText="SNo" />
                        <asp:TemplateField HeaderText="QuestionText">
                            <EditItemTemplate>
                                <asp:TextBox ID="etbQuestionText" runat="server" Text='<%# Eval("QuestionText")%>'></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfv1" runat="server" ControlToValidate="etbQuestionText"
                                    ErrorMessage="*"></asp:RequiredFieldValidator>
                            </EditItemTemplate>
                            <ItemTemplate>
                                <%# Eval("QuestionText")%>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Answer1">
                            <EditItemTemplate>
                                <asp:TextBox ID="etbAnswer1" runat="server" Text='<%# Eval("Answer1")%>' TextMode="MultiLine"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfv2" runat="server" ControlToValidate="etbAnswer1"
                                    ErrorMessage="*"></asp:RequiredFieldValidator>
                            </EditItemTemplate>
                            <ItemTemplate>
                                <%# Eval("Answer1")%>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Answer2">
                            <EditItemTemplate>
                                <asp:TextBox ID="etbAnswer2" runat="server" Text='<%# Eval("Answer2")%>' TextMode="MultiLine"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfv3" runat="server" ControlToValidate="etbAnswer2"
                                    ErrorMessage="*"></asp:RequiredFieldValidator>
                            </EditItemTemplate>
                            <ItemTemplate>
                                <%# Eval("Answer2")%>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Answer3">
                            <EditItemTemplate>
                                <asp:TextBox ID="etbAnswer3" runat="server" Text='<%# Eval("Answer3")%>' TextMode="MultiLine"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfv4" runat="server" ControlToValidate="etbAnswer3"
                                    ErrorMessage="*"></asp:RequiredFieldValidator>
                            </EditItemTemplate>
                            <ItemTemplate>
                                <%# Eval("Answer3")%>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Answer4">
                            <EditItemTemplate>
                                <asp:TextBox ID="etbAnswer4" runat="server" Text='<%# Eval("Answer4")%>' TextMode="MultiLine"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfv5" runat="server" ControlToValidate="etbAnswer4"
                                    ErrorMessage="*"></asp:RequiredFieldValidator>
                            </EditItemTemplate>
                            <ItemTemplate>
                                <%# Eval("Answer4")%>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="CorrectAnswer">
                            <EditItemTemplate>
                                <asp:TextBox ID="etbCorrectAnswer" runat="server" Text='<%# Eval("CorrectAnswer")%>'
                                    TextMode="MultiLine"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfv6" runat="server" ControlToValidate="etbCorrectAnswer"
                                    ErrorMessage="*"></asp:RequiredFieldValidator>
                            </EditItemTemplate>
                            <ItemTemplate>
                                <%# Eval("CorrectAnswer")%>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Marks">
                            <EditItemTemplate>
                                <asp:TextBox ID="etbMarksfortheQuestion" runat="server" Text='<%# Eval("Marks")%>'
                                    TextMode="MultiLine"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfv7" runat="server" ControlToValidate="etbMarksfortheQuestion"
                                    ErrorMessage="*"></asp:RequiredFieldValidator>
                            </EditItemTemplate>
                            <ItemTemplate>
                                <%# Eval("Marks")%>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:CommandField CausesValidation="False" ShowDeleteButton="True" ShowEditButton="True" />
                    </Columns>
                    <FooterStyle BackColor="#99CCCC" ForeColor="#003399" />
                    <PagerStyle BackColor="#99CCCC" ForeColor="#003399" HorizontalAlign="Left" />
                    <EmptyDataTemplate>
                        No Data In The Table
                    </EmptyDataTemplate>
                    <SelectedRowStyle BackColor="#009999" Font-Bold="True" ForeColor="#CCFF99" />
                    <HeaderStyle BackColor="#003399" Font-Bold="True" ForeColor="#CCCCFF" />
                </asp:GridView>
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
               
                <br />
                <asp:Panel ID="panelEdit" runat="server" Height="24px" Style="left: 152px; position: absolute;
                    top: 40px" Visible="false" Width="536px">
                    <table style="left: 0px; width: 496px; position: relative; top: 16px; height: 280px">
                        <tr>
                            <td colspan="2" style="font-size: x-large; font-family: 'Times New Roman', Times, serif;
                                height: 29px; text-decoration: underline; background-color: #ffff33;">
                                Update Questions</td>
                        </tr>
                        <tr>
                            <td style="width: 120px; height: 26px">
                                Question Text
                            </td>
                            <td style="width: 155px; height: 26px">
                                <asp:TextBox ID="txtQuestionText" runat="server" TextMode="MultiLine" Width="272px"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfvQuestionText" runat="server" ControlToValidate="txtQuestionText"
                                    ErrorMessage="*" Style="left: 216px; position: relative; top: -30px"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 120px">
                                Answer 1
                            </td>
                            <td style="width: 155px">
                                <asp:TextBox ID="txtAns1" runat="server" TextMode="MultiLine" Width="272px"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfvAns1" runat="server" ControlToValidate="txtAns1"
                                    ErrorMessage="*" Style="left: 216px; position: relative; top: -30px"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 120px">
                                Answer 2
                            </td>
                            <td style="width: 155px">
                                <asp:TextBox ID="txtAns2" runat="server" TextMode="MultiLine" Width="272px"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfvAns2" runat="server" ControlToValidate="txtAns2"
                                    ErrorMessage="*" Style="left: 216px; position: relative; top: -30px"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 120px">
                                Answer 3
                            </td>
                            <td style="width: 155px">
                                <asp:TextBox ID="txtAns3" runat="server" TextMode="MultiLine" Width="272px"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfvAns3" runat="server" ControlToValidate="txtAns3"
                                    ErrorMessage="*" Style="left: 216px; position: relative; top: -30px" Width="16px"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 120px">
                                Answer 4
                            </td>
                            <td style="width: 155px">
                                <asp:TextBox ID="txtAns4" runat="server" TextMode="MultiLine" Width="272px"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfvAns4" runat="server" ControlToValidate="txtAns4"
                                    ErrorMessage="*" Style="left: 216px; position: relative; top: -30px"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 120px">
                                Correct Answer
                            </td>
                            <td style="width: 155px">
                                <asp:TextBox ID="txtCorrectAnswer" runat="server" TextMode="MultiLine" Width="272px"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfvCorrectAnswer" runat="server" ControlToValidate="txtCorrectAnswer"
                                    ErrorMessage="*" Style="left: 216px; position: relative; top: -30px"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 120px">
                                Marks For Question
                            </td>
                            <td style="width: 155px">
                                <asp:TextBox ID="txtMarksForQuestion" runat="server" Width="264px"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfvMarksForQuestion" runat="server" ControlToValidate="txtMarksForQuestion"
                                    ErrorMessage="*" Style="left: 208px; position: relative; top: -22px"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="background-color: #ffff33">
                                <asp:Button ID="btnUpdate" runat="server" OnClick="btnUpdate_Click" Text="Update"
                                    Width="128px" />
                            </td>
                        </tr>
                        <tr>
                            <td align="right" colspan="12" style="width: 120px; height: 40px">
                                &nbsp;</td>
                        </tr>
                        <asp:Label ID="lblMsg" runat="server" Text=""></asp:Label></table>
                </asp:Panel>
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
            </asp:Panel>
            <br />
            &nbsp;<br />
            <br />
            <br />
    
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
        </asp:Panel>
        &nbsp;&nbsp;
    </center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
</asp:Content>
