﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using OnlineWebBasedExam;

public partial class admin_frmBatchReport : System.Web.UI.Page
{
     
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["ETI"] = "";              
    }


    BALexam Report = new BALexam(); 
    public void fillgrid()
    {
       try
       {
           if (ddlExamId.Text=="Select")
           {
               GVScheduleExam.Visible = false;
               LblMsg.Text="Select Paper";
          
            }
           else
           {
            GVScheduleExam.Visible = true;
            LblMsg.Text = "";
            Report.ExamId = Convert.ToInt32(ddlExamId.SelectedValue);            
            GVScheduleExam.DataSource = Report.gettblBatchReport();
            GVScheduleExam.DataBind();
            if (GVScheduleExam.Rows.Count == 0)
            {
                GVScheduleExam.Visible = false;
                 LblMsg.Text = "No Record Found";
            }
            else
                GVScheduleExam.Visible = true;
        }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
                      
    }



 
    protected void ddlExamId_DataBound(object sender, EventArgs e)
    {
        ddlExamId.Items.Insert(0, "Select");
        GVScheduleExam.Visible = false;
        LblMsg.Text = "";
    }
    protected void ddlExamId_SelectedIndexChanged(object sender, EventArgs e)
    {
        fillgrid();
    }
}
