﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="~/admin/frmExamType.aspx.cs" Inherits="Admin_frmExamType" Title="Untitled Page" %>

<asp:Content ID="Content1" runat="server" contentplaceholderid="ContentBody">
    <center>
        &nbsp;
        
        <asp:Panel ID="PanelNewUser" runat="server" BackColor="#0000C0" Height="480px" Style="left: 0px;
            position: absolute; top: 80px; background-color: #ffffff" Width="840px">
            
            
<table style="left: 208px; position: absolute; top: 24px">
<tr><td colspan="2" style="font-size: x-large">Exam Type Details</td></tr>
<tr><td style="font-size: small">Exam Type Name</td><td><asp:TextBox ID="txtExamTypeId" runat="server" Width="150"></asp:TextBox>
    <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtExamTypeId" ErrorMessage="*"></asp:RequiredFieldValidator>
    </td></tr>
<tr><td style="font-size: small">Description</td><td><asp:TextBox ID="txtDescription" runat="server" Width="150"></asp:TextBox>
    <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ControlToValidate="txtDescription" ErrorMessage="*"></asp:RequiredFieldValidator>
    </td></tr>
<tr><td colspan="2">
<asp:Button ID="btnSubmit" runat="server" Text="Submit" onclick="btnSubmit_Click" />
&nbsp 
    <asp:Button ID="tbEdit" runat="server" Text="Edit" onclick="tbEdit_Click" 
        style="height: 26px" CausesValidation="False" />
</td></tr>
<tr><td colspan="2">
    &nbsp;<asp:Label ID="lblMsg" runat="server" Text=""></asp:Label>
    <br />
    <asp:GridView ID="gvExamType" runat="server" AutoGenerateColumns="False" 
        CellPadding="4" ForeColor="#333333" GridLines="None" 
        onrowcancelingedit="gvExamType_RowCancelingEdit1" 
        onrowdeleting="gvExamType_RowDeleting1" onrowediting="gvExamType_RowEditing1" 
        onrowupdating="gvExamType_RowUpdating" Visible="False" OnSelectedIndexChanged="gvExamType_SelectedIndexChanged">
        <FooterStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" />
        <RowStyle BackColor="#F7F6F3" ForeColor="#333333" />
    <Columns>
    
            <asp:TemplateField HeaderText="ExamTypeID">
              <ItemTemplate>
                  <asp:Label ID="EtbExamTypeID" runat="server" Text='<%# Eval("ExamTypeID") %>' Visible="<%# false %>"></asp:Label><%# Eval("ExamTypeId")%>
              </ItemTemplate>
              <EditItemTemplate>
                  &nbsp;<asp:Label ID="EtbExamTypeID" runat="server" Text='<%# Eval("ExamTypeID") %>'></asp:Label>
              </EditItemTemplate>            
            </asp:TemplateField>
    
            <asp:TemplateField HeaderText="ExamTypeName">
              <ItemTemplate>
                <%# Eval("ExamTypeName")%>
              </ItemTemplate>
              <EditItemTemplate>
              <asp:TextBox ID="etbExamTypeName" runat="server" Text='<%# Eval("ExamTypeName")%>' ></asp:TextBox>
              <asp:RequiredFieldValidator ID="rfv1" runat="server" ControlToValidate="etbExamTypeName" ErrorMessage="*"></asp:RequiredFieldValidator>
              </EditItemTemplate>
            </asp:TemplateField>
            
             <asp:TemplateField HeaderText="Description">
              <ItemTemplate>
                <%# Eval("Description")%>
              </ItemTemplate>
              <EditItemTemplate>
              <asp:TextBox ID="etbDescription" runat="server" TextMode="MultiLine" Text='<%# Eval("Description")%>' ></asp:TextBox>
              <asp:RequiredFieldValidator ID="rfv2" runat="server" ControlToValidate="etbDescription" ErrorMessage="*"></asp:RequiredFieldValidator>
              </EditItemTemplate>
            </asp:TemplateField>
            
            <asp:TemplateField HeaderText="Date">
              <ItemTemplate>
                <%# Eval("Date")%>
              </ItemTemplate>
              <EditItemTemplate>
              <asp:TextBox ID="etbDate" runat="server" Text='<%# Eval("Date")%>' ></asp:TextBox>
              <asp:RequiredFieldValidator ID="rfv3" runat="server" ControlToValidate="etbDate" ErrorMessage="*"></asp:RequiredFieldValidator>
              </EditItemTemplate>
            </asp:TemplateField>
            
            <asp:CommandField ShowEditButton="True" ShowDeleteButton="True" CausesValidation="False" />
    </Columns>

        <PagerStyle BackColor="#284775" ForeColor="White" HorizontalAlign="Center" />
        <SelectedRowStyle BackColor="#E2DED6" Font-Bold="True" ForeColor="#333333" />
        <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" />
        <EditRowStyle BackColor="#999999" />
        <AlternatingRowStyle BackColor="White" ForeColor="#284775" />
    </asp:GridView>
    &nbsp;
    </td></tr>
<tr><td colspan="2">
    &nbsp;&nbsp;<br />
    <asp:HyperLink ID="HyperLink1" runat="server" NavigateUrl="~/admin/frmExamType.aspx"
        Visible="False" Width="56px">Back</asp:HyperLink></td></tr>
</table>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
        </asp:Panel>
</center>
</asp:Content>