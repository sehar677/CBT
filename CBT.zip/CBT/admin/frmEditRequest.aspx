﻿<%@ Page Language="C#" MasterPageFile="~/admin/AdminMasterPage.master" AutoEventWireup="true" CodeFile="~/admin/frmEditRequest.aspx.cs" Inherits="Admin_frmEditRequest" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
    <center>
        <asp:Panel ID="Panel1" runat="server" Height="416px" Width="1008px" style="left: -230px; position: absolute; top: -14px">
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
            <table border="0" style="left: -30px; width: 912px; position: relative; top: -14px;
                height: 80px">
                <tr>
                    <td colspan="13" style="font-size: x-large; width: 461px; height: 12px; color: #ffffff; background-color: #336699;">
                        Manage Exam Request</td>
                </tr>
                <tr>
                    <td align="left" colspan="2" style="width: 65px; height: 23px">
                        Select Examination</td>
                    <td align="left" colspan="1" style="width: 216px; height: 23px">
                        Select Paper</td>
                    <td align="left" colspan="1" style="width: 151px; height: 23px">
                        Exam ID</td>
                    <td align="left" colspan="1" style="width: 151px; height: 23px">
                    </td>
                    <td align="left" colspan="1" style="width: 151px; height: 23px">
                        &nbsp;</td>
                </tr>
                <tr>
                    <td align="left" colspan="2" style="width: 65px; height: 3px">
                        <asp:DropDownList ID="DropDownList1" runat="server" AutoPostBack="True" DataSourceID="SqlDataExam"
                            DataTextField="ExamTypeName" DataValueField="ExamTypeId" Width="264px">
                        </asp:DropDownList></td>
                    <td align="left" colspan="1" style="width: 216px; height: 3px">
                        <asp:DropDownList ID="DropDownList2" runat="server" AutoPostBack="True" OnDataBound="DropDownList2_DataBound"
                            OnSelectedIndexChanged="DropDownList2_SelectedIndexChanged" Width="264px" DataSourceID="SqlDataPaper" DataTextField="ExamName" DataValueField="ExamId">
                        </asp:DropDownList></td>
                    <td align="left" colspan="1" style="width: 151px; height: 3px">
                        <asp:TextBox ID="TxtExamId" runat="server" CausesValidation="True" Width="136px"></asp:TextBox></td>
                    <td align="left" colspan="1" style="width: 151px; height: 3px">
                        <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="TxtExamId"
                            ErrorMessage="*"></asp:RequiredFieldValidator></td>
                    <td align="left" colspan="1" style="width: 151px; height: 3px">
                        <asp:Button ID="btnSubmit" runat="server" Height="24px" OnClick="btnSubmit_Click"
                            Style="left: 352px; top: 7px" Text="Cancel Requests" Width="136px" /></td>
                </tr>
            </table>
            <asp:GridView ID="GVScheduleExam" runat="server" AutoGenerateColumns="False" OnRowEditing="GVScheduleExam_RowEditing"
                Style="left: -30px; position: relative; top: -6px" Visible="False" Width="912px" BackColor="White" BorderColor="#CCCCCC" BorderStyle="None" BorderWidth="1px" CellPadding="3">
                <Columns>
                    <asp:BoundField DataField="UserId" HeaderText="UserId" />
                    <asp:BoundField DataField="UserName" HeaderText="User Name" SortExpression="FName" />
                    <asp:BoundField DataField="PreferedDate" HeaderText="Exam Preferable Date" />
                    <asp:BoundField DataField="ExamRequestId" HeaderText="ExamRequestId" />
                    <asp:BoundField DataField="ExamTypeId" HeaderText="ExamTypeId" />
                    <asp:BoundField DataField="ExamId" HeaderText="Exam ID" />
                    <asp:BoundField DataField="ExamName" HeaderText="Exam Name" SortExpression="ExamName" />
                    <asp:BoundField DataField="CurStatus" HeaderText="Status" SortExpression="CurStatus" />
                    <asp:CommandField CausesValidation="False" EditText="Cancel Request" ShowEditButton="True" />
                </Columns>
                <EmptyDataTemplate>
                    No Data In The Table
                </EmptyDataTemplate>
                <RowStyle ForeColor="#000066" />
                <FooterStyle BackColor="White" ForeColor="#000066" />
                <PagerStyle BackColor="White" ForeColor="#000066" HorizontalAlign="Left" />
                <SelectedRowStyle BackColor="#669999" Font-Bold="True" ForeColor="White" />
                <HeaderStyle BackColor="#006699" Font-Bold="True" ForeColor="White" />
            </asp:GridView>
            <asp:Label ID="LblMsg" runat="server" Style="left: 464px; position: absolute; top: 304px"
                Text=""></asp:Label>
        </asp:Panel>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
            <asp:Panel ID="Panel2" runat="server" Style="left: 624px; position: absolute; top: 24px">
                        <asp:SqlDataSource ID="SqlDataExam" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString9 %>"
                            SelectCommand="SELECT [ExamTypeName], [ExamTypeId] FROM [tbl_ExamType]"></asp:SqlDataSource>
                        <asp:SqlDataSource ID="SqlDataPaper" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString9 %>"
                            SelectCommand="SELECT [ExamName], [ExamId] FROM [tbl_Exams] WHERE ([ExamTypeId] = @ExamTypeId)">
                            <SelectParameters>
                                <asp:ControlParameter ControlID="DropDownList1" Name="ExamTypeId" PropertyName="SelectedValue"
                                    Type="Int32" />
                            </SelectParameters>
                        </asp:SqlDataSource>
            <asp:SqlDataSource ID="SqlDataGrid" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString9 %>"
                SelectCommand="SELECT * FROM [tbl_ExamRequest] WHERE ([Status] = @Status)">
                <SelectParameters>
                    <asp:Parameter DefaultValue="0" Name="Status" Type="Int32" />
                </SelectParameters>
            </asp:SqlDataSource>
            </asp:Panel>
            &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
    <center>
        &nbsp;</center>
</asp:Content>

