﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Login: System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
         
      
         
       
    }
    protected void BtnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            
            Session["User"] = txtUserName.Text;    
            string Role = BALLogin.adminsLogins(Session["User"].ToString(), txtPassword.Text);
            string varStatus = BALLogin.Login(Session["User"].ToString(), txtPassword.Text);
            Session["Role"] = Role;
            if (Role != null)
            {

                if (Role.ToUpper() == "STUDENT" || Role.ToUpper() == "ADMIN")
                {
                    if (varStatus.ToString() == "1")
                    {
                      FormsAuthentication.RedirectFromLoginPage(Role, false);
                    }
                    else
                    {
                        lblMsg.Text = "User Not Verified";
                    }

                   
                }
                else
                    lblMsg.Text = "Invalid User Name or Password";

                
            }
            else
                lblMsg.Text = "User Not Registered";
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

     
}
