﻿<%@ Page Language="C#" MasterPageFile="~/Registration/MainMasterPage.master" AutoEventWireup="true" CodeFile="Login.aspx.cs" Inherits="Login" Title="Untitled Page" %>
 
<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" Runat="Server">
 <html>
    <center>
    
<form id="form1" runat="server">
    <asp:Panel ID="Panel1" runat="server" style="left: 410px; position: absolute; top: 149px" Height="264px">
<table border="0" style="width: 344px; height: 160px; background-color: sandybrown">
<tr><td colspan="2" style="font-size: x-large; height: 29px; background-color: white;" align="left">Login Form
    <asp:HyperLink ID="HyperLink1" runat="server" Font-Bold="True" Font-Size="Medium"
        NavigateUrl="~/Default.aspx" Style="left: 295px; position: absolute; top: 7px"
        Width="1px">Home</asp:HyperLink>
</td></tr>
    <tr>
        <td style="height: 13px">
            </td>
        <td style="width: 241px; height: 13px;">
            &nbsp;</td>
    </tr>
<tr><td>User Name</td>
<td style="width: 241px"><asp:TextBox ID="txtUserName" runat="server" Width="150" Height="20px"></asp:TextBox>
    <asp:RequiredFieldValidator ID="rfvUserName" runat="server" ControlToValidate="txtUserName" ErrorMessage="*"></asp:RequiredFieldValidator>
</td></tr>

<tr><td>Password</td>
<td style="width: 241px"><asp:TextBox ID="txtPassword" runat="server" Width="150" TextMode="Password" Height="22px">admin</asp:TextBox>
    <asp:RequiredFieldValidator ID="rfvPassword" runat="server" ControlToValidate="txtPassword" ErrorMessage="*"></asp:RequiredFieldValidator>
</td></tr>
    <tr>
        <td style="height: 9px">
        </td>
        <td style="width: 241px; height: 9px">
        </td>
    </tr>
    <tr>
        <td colspan="2" style="height: 28px">
  <asp:Button ID="BtnLogin" runat="server" Text="Login" onclick="BtnLogin_Click" 
        Width="90px" Height="28px" /></td>
    </tr>

<tr><td colspan="2" style="height: 28px; background-color: #ffffff;">
    &nbsp; &nbsp;&nbsp;
<asp:Label ID="lblMsg" runat="server" Width="304px"></asp:Label></td>
</tr>
</table>
        <br />
        &nbsp;<br />
</asp:Panel>
    &nbsp;&nbsp;&nbsp;<br />
</form>
</center>
</html>
</asp:Content>

