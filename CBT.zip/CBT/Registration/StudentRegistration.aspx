﻿<%@ Page Language="C#" MasterPageFile="../Registration/MainMasterPage.master" AutoEventWireup="true"
    CodeFile="StudentRegistration.aspx.cs" Inherits="StudentRegistration" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentBody" runat="Server">
    <center>
        <form id="form1" runat="server">
            <asp:Panel ID="Panel1" runat="server" Height="623px" Style="left: 214px; position: absolute;
                top: 81px" Width="424px">
        <table   style="width: 412px; height: 448px; background-color: #ffffff; left: 7px; position: absolute; top: 8px;">
            <tr>
                <td colspan="1" style="height: 21px; font-style: italic; font-family: Calibri; background-color: #33cc00; text-align: left; font-variant: normal;">
                    Registration Form
                    <br />
                </td>
                <td colspan="1" style="width: 29px; font-style: italic; font-family: Calibri; height: 21px;
                    background-color: #33cc00; text-align: left; font-variant: normal">
                    <asp:HyperLink ID="HyperLink1" runat="server" Font-Size="Medium" NavigateUrl="~/Default.aspx"
                        Width="112px" style="color: #ffffff; text-align: right; left: 259px; position: absolute; top: 3px;">Home</asp:HyperLink>
                </td>
            </tr>
            <tr style="width: 176px">
                <td align="left" style="width: 263px; height: 40px">
                    Select Trade</td>
                <td style="width: 213px; height: 40px">
                    <asp:DropDownList ID="ddlExamTypeId" runat="server" DataSourceID="SqlDataSource1"
                        DataTextField="ExamTypeName" DataValueField="ExamTypeName" Style="left: 416px;
                        position: static; top: 568px" Width="204px">
                    </asp:DropDownList></td>
                <td style="width: 29px; height: 40px">
                </td>
            </tr>
            <tr style="width: 176px">
                <td align="left" style="width: 263px; height: 40px;" >
                    First Name
                </td>
                <td style="width: 213px; height: 40px;">
                    <asp:TextBox ID="txtFName" runat="server" Width="210px"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 29px; height: 40px">
                    <asp:RequiredFieldValidator ID="rfvFName" runat="server" ControlToValidate="txtFName"
                        ErrorMessage="*"></asp:RequiredFieldValidator></td>
            </tr>
            <tr>
                <td  align="left" style="width: 263px"  >
                    Last Name
                </td>
                <td style="width: 213px">
                    <asp:TextBox ID="txtLName" runat="server" Width="210px"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 29px">
                    <asp:RequiredFieldValidator ID="rfvLName" runat="server" ControlToValidate="txtLName"
                        ErrorMessage="*"></asp:RequiredFieldValidator></td>
            </tr>
            <tr>
                <td align="left" style="width: 263px">
                    Contact No
                </td>
                <td style="width: 213px">
                    <asp:TextBox ID="txtContactNo" runat="server" Width="204px" Height="20px"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 29px">
                    <asp:RequiredFieldValidator ID="rfvContactNo" runat="server" ControlToValidate="txtContactNo"
                        ErrorMessage="*"></asp:RequiredFieldValidator></td>
            </tr>
            <tr>
                <td align="left" style="width: 263px" >
                    Address
                </td>
                <td style="width: 213px">
                    <asp:TextBox ID="txtAddress" runat="server" Width="208px" TextMode="MultiLine"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 29px">
                    <asp:RequiredFieldValidator ID="rfvAddress" runat="server" ControlToValidate="txtAddress"
                        ErrorMessage="*"></asp:RequiredFieldValidator></td>
            </tr>
            <tr>
                <td align="left" style="width: 263px; height: 40px;">
                    User Name
                </td>
                <td style="width: 213px; height: 40px;">
                    <asp:TextBox ID="txtUserName" runat="server" Width="200px" Height="24px"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 29px; height: 40px">
                    <asp:RequiredFieldValidator ID="efvUserName" runat="server" ControlToValidate="txtUserName"
                        ErrorMessage="*"></asp:RequiredFieldValidator></td>
            </tr>
            <tr>
                <td align="left" style="width: 263px">
                    Password
                </td>
                <td style="width: 213px">
                    <asp:TextBox ID="txtPassword" runat="server" Width="202px" TextMode="Password"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 29px">
                    <asp:RequiredFieldValidator ID="rfvpassword" runat="server" ControlToValidate="txtPassword"
                        ErrorMessage="*"></asp:RequiredFieldValidator></td>
            </tr>
            <tr>
                <td align="left" style="width: 263px">
                    Security Question
                </td>
                <td style="width: 213px; height: 23px;">
                    <asp:DropDownList ID="txtSecQues" runat="server" Width="208px">
                        <asp:ListItem Selected="True">Whats is your Fav Color?</asp:ListItem>
                        <asp:ListItem>What is your born place</asp:ListItem>
                        <asp:ListItem>Favorite Book?</asp:ListItem>
                        <asp:ListItem>Favorite Color ?</asp:ListItem>
                    </asp:DropDownList>&nbsp;
                </td>
                <td style="width: 29px; height: 23px">
                    <asp:RequiredFieldValidator ID="rfvsecques" runat="server" ControlToValidate="txtSecQues"
                        ErrorMessage="*"></asp:RequiredFieldValidator></td>
            </tr>
            <tr>
                <td align="left" style="width: 263px">
                    Security Answer
                </td>
                <td style="width: 213px">
                    <asp:TextBox ID="txtSecAns" runat="server" Width="202px"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 29px">
                    <asp:RequiredFieldValidator ID="rfvSecAns" runat="server" ControlToValidate="txtSecAns"
                        ErrorMessage="*"></asp:RequiredFieldValidator></td>
            </tr>
            <tr>
                <td colspan="2">
                </td>
                <td colspan="1" style="width: 29px">
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    &nbsp;<asp:Button ID="btnSubmit" runat="server" Text="Register Me" OnClick="btnSubmit_Click" Width="109px" style="position: relative" /></td>
                <td colspan="1" style="width: 29px">
                </td>
            </tr>
            <tr>
                <td colspan="2">
        <asp:Label ID="lblMsg" runat="server" Text=""></asp:Label></td>
                <td colspan="1" style="width: 29px">
                </td>
            </tr>
        </table>
            </asp:Panel>
            <asp:SqlDataSource ID="SqlDataSource1" runat="server" ConnectionString="<%$ ConnectionStrings:WebBasedExamConnectionString %>"
                SelectCommand="SELECT [ExamTypeName] FROM [tbl_ExamType]"></asp:SqlDataSource>
            &nbsp; &nbsp;
            &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
        </form>
    </center>
</asp:Content>
