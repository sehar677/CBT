﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;

public partial class StudentRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    static int i;
    static string strMsg;
    BALQuestions insobj = new BALQuestions();
    public void InsertStudentDetails()
    {
        insobj.FName = txtFName.Text;
        insobj.LName = txtLName.Text;
        insobj.ContactNo = txtContactNo.Text;
        insobj.Address = txtAddress.Text;
        insobj.UserName = txtUserName.Text;
        insobj.Password = txtPassword.Text;
        insobj.SecQues = txtSecQues.Text;
        insobj.SecAns = txtSecAns.Text;
        insobj.Batch = ddlExamTypeId.Text;
        i = insobj.InsertStudent(out strMsg);
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            InsertStudentDetails();
            if (i > 1)
            {
                ClearData();
                lblMsg.Text = strMsg;
            }
            else
                lblMsg.Text = strMsg;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    public void ClearData()
    {
        txtFName.Text = txtLName.Text = txtContactNo.Text = txtAddress.Text = "";
        txtUserName.Text = txtPassword.Text = txtSecQues.Text = txtSecAns.Text = "";
    }






    






    
}