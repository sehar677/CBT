﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using OnlineWebBasedExam;

public class BALQuestionPaper
{
    public BALQuestionPaper()
    {
    }
    public int id { get; set; }
    public int NoOfQuestion { get; set; }
    public int CorrectAnswers { get; set; }
    public int WrongAnswers { get; set; }
    public int Attempted { get; set; }
    public int NetScore { get; set; }
    public string TimeTaken { get; set; }
   

    public static DataSet ShowExaminationAllDetails(int id,string UserName)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@id", id);
            p[1] = new SqlParameter("@UserName", UserName);
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_SelectExaminationdetails", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public static int AcceptUser(int id, int p1)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@UserId", id);
            p[1] = new SqlParameter("@status", p1);
            return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "Sp_AcceptUser", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public static int Updatestatus(string UserName, int id, int p1)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@UserName", UserName);
            p[1] = new SqlParameter("@ExamId", id);
            p[2] = new SqlParameter("@status", p1);
            return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "Sp_UpdateExamstatus", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }



    public int InsertStudentExaminationDetails(int id, string lblQuestionID, string text, bool p1)
    {
        SqlParameter[] p = new SqlParameter[4];
        p[0] = new SqlParameter("@ExamId", id);
        p[1] = new SqlParameter("@QuestionSNo", lblQuestionID);
        p[2] = new SqlParameter("@Answer", text);
        p[3] = new SqlParameter("@CorrectOrWrong", p1);
        return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "Sp_ExamDetail_Insert", p);
    }


    static string IsNegMarking;
    public static void InsertstudentResults(string UserName, int id, int NoOfQuestion, int CorrectAnswers,int WrongAnswers,int Attempted,int NetScore,string TimeTaken)
    {

     BALQuestionPaper objexamdetails = new BALQuestionPaper();
     objexamdetails.IsNegCheck(id);
     double NS;
        if (IsNegMarking == "Yes")
        {           
            NS = NetScore - (WrongAnswers * 0.25);
        }
        else
        {
            NS = NetScore;
        }


        try
        {
            SqlParameter[] p = new SqlParameter[8];
            p[0] = new SqlParameter("@UserName", UserName);
            p[1] = new SqlParameter("@Examid", id);
            p[2] = new SqlParameter("@NoOfQuestion", NoOfQuestion);
            p[3] = new SqlParameter("@CorrectAnswers", CorrectAnswers);
            p[4] = new SqlParameter("@WrongAnswers",WrongAnswers);
            p[5] = new SqlParameter("@Attempted",Attempted);
            //p[6] = new SqlParameter("@NetScore",NetScore);
            p[6] = new SqlParameter("@NetScore", NS);
            p[7] = new SqlParameter("@TimeTaken",TimeTaken);
            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "Sp_InsertResult", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public int FindQuestions(out int outques,int id)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@id", id);
            p[1] = new SqlParameter("@Out", SqlDbType.VarChar, 150);
            p[1].Direction = ParameterDirection.Output;
            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_FindNoOfQuestions", p);
            outques =Convert.ToInt32(p[1].Value.ToString());
            return i;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public DataSet DisplayResult(int id,String UserName )
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@examId",id);
            p[1] = new SqlParameter("@UserName", UserName);
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "sp_DisplayResult", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public DataSet GetIsNegMarking(int examid)
    {
        try
        {
            string strCmdText = "select NegativeMarking from tbl_Exams where Examid=" + examid;
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public void IsNegCheck(int id)
    {
        DataSet ds = GetIsNegMarking(id);
        if (ds.Tables[0].Rows.Count != 0)
        {
            IsNegMarking = ds.Tables[0].Rows[0][0].ToString();
        }
        else
        {
            IsNegMarking = "No";
        }
    }
}