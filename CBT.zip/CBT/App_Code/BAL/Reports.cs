﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using OnlineWebBasedExam;

public class Reports
{
	public Reports()
	{
    }

    public static DataSet GetExamReport()
    {
        try
        {
            return SqlHelper.ExecuteDataset(Connection.con, "spGetExamReport");
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public static DataSet GetStudentReport()
    {
        try
        {
            return SqlHelper.ExecuteDataset(Connection.con, "spGetStudentReport");
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public static DataSet GetSReport(string  ExamName)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@ExamName", ExamName);

            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "spGetStudentReport", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public static DataSet GetSSingleReport(string ExamName, string UserName)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@ExamName", ExamName);
            p[1] = new SqlParameter("@UserName", UserName);

            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "spGetStudentSingleReport", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
}
