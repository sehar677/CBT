﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using OnlineWebBasedExam;

/// <summary>
/// Summary description for BALQuestions
/// </summary>
public class BALQuestions
{
	
    public int examid { get; set; }
    public string  questiontext { get; set; }
    public string  answer1 { get; set; }
    public string  answer2 { get; set; }
    public string  answer3 {get; set; }
    public string  answer4 { get; set; }
    public string  correctanswer { get; set; }
    public int marksforquestion { get; set; }
    public int Id { get; set; }
    public int SNo { get; set; }
    public string  FName { get; set; }
    public string  LName { get; set; }
    public string  ContactNo { get; set; }
    public string  Address { get; set; }
    public string DOB { get; set; }
    public string  UserName { get; set; }
    public string  Password { get; set; }
    public string  SecQues { get; set; }
    public string SecAns { get; set; }
    public string Batch { get; set; }
    public string  Out { get; set; }



    public object getNQ(int id)
    {
        try
        {
            string strCmdText = "select count(*) from tbl_ExamQuestion where ExamID="+id;
            object o=SqlHelper.ExecuteScalar(Connection.con, CommandType.Text, strCmdText);            
            return o;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    
    public DataSet gettblquestions(int ExamId)
    {
        try
        {
            string strCmdText = "select QuestionSNo,QuestionText,Answer1,Answer2,Answer3,Answer4,CorrectAnswer,Marks from tbl_ExamQuestion where ExamID="+ExamId;
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }



    public int InsertQuestion(out string outMsg)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[9];
            p[0] = new SqlParameter("@ExamId", examid);
            p[1] = new SqlParameter("@QuestionText", questiontext);
            p[2] = new SqlParameter("@Answer1", answer1);
            p[3] = new SqlParameter("@Answer2", answer2);
            p[4] = new SqlParameter("@Answer3", answer3);
            p[5] = new SqlParameter("@Answer4",answer4);
            p[6] = new SqlParameter("@CorrectAnswer", correctanswer);
            p[7] = new SqlParameter("@MarksforQuestion", marksforquestion);
            p[8] = new SqlParameter("@Out", SqlDbType.VarChar, 150);
            p[8].Direction = ParameterDirection.Output;

            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_InsertQuestions", p);
            outMsg = p[8].Value.ToString();
            return i;
        }
        catch (Exception ex)
        {
            throw new NotImplementedException();
             
        }
    }





    public int getdeletetblquestion(int sno)
    {
        try
        {
            string strCmdText = "delete tbl_ExamQuestion where QuestionSNo=" + sno;
            return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }





    public int GetUpdatetblQuestion(string questiontext, string ans1, string ans2, string ans3, string ans4,string correctans,int noofmarks, int id)
    {
        try
        {
            string strCmdText = "Update tbl_ExamQuestion set QuestionText='" + questiontext + "',Answer1='" + ans1 + "', Answer2='" + ans2 + "',Answer3='" + ans3 + "',Answer4='" + ans4 + "',CorrectAnswer='" + correctans + "',MarksfortheQuestion="+noofmarks+" where ExamId=" + id;
            return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }




    public DataSet GetQuestionDetails()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@SNo", SqlDbType.Int);
            p[0].Value = Id;
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "spGetQuestionDetails", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }





    public void UpdateQuestion()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[8];
            p[0] = new SqlParameter("@SNo", SqlDbType.Int);
            p[0].Value = SNo;
            p[1] = new SqlParameter("@QuestionText", SqlDbType.VarChar);
            p[1].Value = questiontext;
            p[2] = new SqlParameter("@Answer1", SqlDbType.VarChar);
            p[2].Value = answer1;
            p[3] = new SqlParameter("@Answer2", SqlDbType.VarChar);
            p[3].Value = answer2;
            p[4] = new SqlParameter("@Answer3", SqlDbType.VarChar);
            p[4].Value = answer3;
            p[5] = new SqlParameter("@Answer4", SqlDbType.VarChar);
            p[5].Value = answer4;
            p[6] = new SqlParameter("@CorrectAnswer", SqlDbType.VarChar);
            p[6].Value = correctanswer;
            p[7] = new SqlParameter("@MarksfortheQuestion", SqlDbType.Int);
            p[7].Value = marksforquestion;
            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "spUpdateQuestions", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }



    public int InsertStudent(out string OutMsg)
    {
        SqlParameter[] p=new SqlParameter[10];
        p[0] = new SqlParameter("@FName", SqlDbType.VarChar,50);
        p[0].Value = FName;

        p[1] = new SqlParameter("@LName", SqlDbType.VarChar,50);
        p[1].Value = LName;

        p[2] = new SqlParameter("@ContactNo", SqlDbType.VarChar,20);
        p[2].Value = ContactNo;

        p[3] = new SqlParameter("@Address", SqlDbType.VarChar,1000);
        p[3].Value = Address;

        //p[4] = new SqlParameter("@DOB", SqlDbType.VarChar,50);
        //p[4].Value = DOB;

        p[4] = new SqlParameter("@UserName", SqlDbType.VarChar,50);
        p[4].Value = UserName;

        p[5] = new SqlParameter("@Password", SqlDbType.VarChar,50);
        p[5].Value = Password;

        p[6] = new SqlParameter("@SecQues", SqlDbType.VarChar,100);
        p[6].Value = SecQues;

        p[7] = new SqlParameter("@SecAns", SqlDbType.VarChar,100);
        p[7].Value = SecAns;

        p[8] = new SqlParameter("@Batch", SqlDbType.VarChar, 100);
        p[8].Value = Batch;

        p[9] = new SqlParameter("@Out", SqlDbType.VarChar,100);
        p[9].Direction = ParameterDirection.Output;

        int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_Insertstudent", p);
        OutMsg = p[9].Value.ToString();
        return i;
    }
}