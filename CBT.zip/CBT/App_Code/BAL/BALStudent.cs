﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using OnlineWebBasedExam;

/// <summary>
/// Summary description for BALStudent
/// </summary>
public class BALStudent
{
	public BALStudent()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static DataSet Getusername(string username)
    {
        try
        {
            return SqlHelper.ExecuteDataset(Connection.con, "spGetUserDetais", username);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public void updateAccountinfo(int userid, string fname, string lname, string contactno, string address)
    {
        try
        {
            
            string str = "Update tbl_userDetails set Fname='" + fname + "', lname='" + lname + "',contactno='" + contactno + "',address='" + address + "' where userid=" + userid;
            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
}