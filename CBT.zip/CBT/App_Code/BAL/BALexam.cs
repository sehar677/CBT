﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using OnlineWebBasedExam;

/// <summary>
/// Summary description for BALexam
/// </summary>
public class BALexam
{
    private string examtypename;
    private string desc;
    private string examname;
    private string dor;
    private int noofquestions;
    private string negativemarking;
    private int examtypeid;
    

    public int uid { get; set; }
    public string ExamReqDate { get; set; }
    public string  UserName { get; set; }
    public int ExamId { get; set; }
    public string ExamAssignDate { get; set; }
    public string KeyCode { get; set; }
    public int ExamRequestId { get; set; }
    public string CurStatus { get; set; }
    public int TimeDuration { get; set; }

    public string Desc{get { return desc; }set { desc = value; }}
    public string Examtypename{get { return examtypename; }set { examtypename = value; }}
    public string Examname { get { return examname; } set { examname = value; } }
    public string Dor { get { return dor; } set { dor = value; } }
    public int Noofquestions { get { return noofquestions; } set { noofquestions = value; } }
    public string Negativemarking { get { return negativemarking; } set { negativemarking = value; } }
    public int Examtypeid { get { return examtypeid; } set { examtypeid = value; } }
  
    public BALexam()
    { }

    public int InsertExamType(out string outMsg)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@ExamTypeName", Examtypename);
            p[1] = new SqlParameter("@Desc", Desc);
            p[2] = new SqlParameter("@Out", SqlDbType.VarChar, 150);
            p[2].Direction = ParameterDirection.Output;

            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_InsertExamType", p);
            outMsg = p[2].Value.ToString();
            return i;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }



    public int InsertExamName(out string outMsg)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[7];
            p[0] = new SqlParameter("@ExamTypeId", Examtypeid);
            p[1] = new SqlParameter("@ExamName", Examname);
            p[2] = new SqlParameter("@Description", Desc);
            p[3] = new SqlParameter("@NoOfQues", Noofquestions);
            p[4] = new SqlParameter("@NegativeMarking", Negativemarking);
            p[5] = new SqlParameter("@TimeDuration", TimeDuration);
            p[6] = new SqlParameter("@Out", SqlDbType.VarChar, 150);
            p[6].Direction = ParameterDirection.Output;

            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_InsertExams", p);
            outMsg = p[6].Value.ToString();
            return i;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    
    public DataSet gettblexams()
    {
        try
        {
            string strCmdText = "Select ExamId,ExamName,Description,DOR,NoOfQuestions,NegativeMarking,Duration from tbl_Exams where status=1 and ExamTypeId="+Examtypeid;
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public int getdeletetblexams(int id)
    {
        try
        {
            string strCmdText = "delete tbl_Exams where Examid="+id;
            return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public int GetUpdatetblExams(string name,string desc,string dor,int noofques,int duration,string negmarking,int id)
    {
        try
        {
            string strCmdText = "Update tbl_Exams set ExamName='" + name + "',Description='" + desc + "', DOR='" + dor + "',NoOfQuestions=" + noofques + ",Duration=" + duration + ",NegativeMarking='" + negmarking + "' where ExamId=" + id;
            return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public int InsertExamRequest(out string outMsg)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[6];
            p[0] = new SqlParameter("@preferedDate",ExamReqDate);
            p[1] = new SqlParameter("@UserName", UserName);
            p[2] = new SqlParameter("@ExamTypeId", Examtypeid);
            p[3] = new SqlParameter("@ExamId", ExamId);
            p[4] = new SqlParameter("@Out", SqlDbType.VarChar, 15);
            p[4].Direction = ParameterDirection.Output;
            p[5] = new SqlParameter("@CurStatus", CurStatus);
 
            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure,"sp_ExamRequest", p);
            outMsg = p[4].Value.ToString();
            return i;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public int InsertExamRequestAll(out string outMsg)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];
            p[0] = new SqlParameter("@preferedDate", ExamReqDate);
            p[1] = new SqlParameter("@ExamTypeId", Examtypeid);
            p[2] = new SqlParameter("@ExamId", ExamId);
            p[3] = new SqlParameter("@Out", SqlDbType.VarChar, 15);
            p[3].Direction = ParameterDirection.Output;
            p[4] = new SqlParameter("@CurStatus", CurStatus);

            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_ExamRequestAll", p);
            outMsg = p[3].Value.ToString();
            return i;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public int CancelExamRequest(out string outMsg)
    {
        try
        {
            String query = "delete FROM tbl_ExamRequest WHERE status=0 and ExamRequestId=" + ExamRequestId;
            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, query);
            outMsg ="Record Updated";
            return i;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public int CancelExamRequestAll(out string outMsg)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@ExamTypeId", Examtypeid);
            p[1] = new SqlParameter("@ExamId", ExamId);
            p[2] = new SqlParameter("@Out", SqlDbType.VarChar, 15);
            p[2].Direction = ParameterDirection.Output;

            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_CancelExamRequest", p);
            outMsg = p[2].Value.ToString();
            return i;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public int InsertScheduleExam(out string outMsg)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[7];
            p[0] = new SqlParameter("@ExamAssignDate", ExamAssignDate);
            p[1] = new SqlParameter("@UserName", UserName);
            p[2] = new SqlParameter("@Keycode", KeyCode);
            p[3] = new SqlParameter("@ExamId", ExamId);
            p[4] = new SqlParameter("@UserId", uid);
            p[5] = new SqlParameter("@ExamRequestId", ExamRequestId);
            p[6] = new SqlParameter("@Out", SqlDbType.VarChar, 150);
            p[6].Direction = ParameterDirection.Output;

            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_InsertSchedule", p);
            outMsg = p[6].Value.ToString();
            return i;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public int InsertScheduleExamAll(out string outMsg)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[7];
            p[0] = new SqlParameter("@ExamAssignDate", ExamAssignDate);
            p[1] = new SqlParameter("@UserName", UserName);
            p[2] = new SqlParameter("@Keycode", KeyCode);
            p[3] = new SqlParameter("@ExamId", ExamId);
            p[4] = new SqlParameter("@UserId", uid);
            p[5] = new SqlParameter("@ExamRequestId", ExamRequestId);
            p[6] = new SqlParameter("@Out", SqlDbType.VarChar, 150);
            p[6].Direction = ParameterDirection.Output;

            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_InsertScheduleAll", p);
            outMsg = p[6].Value.ToString();
            return i;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public int CancelScheduleExam(out string outMsg)
    {
        try
        {  
            String query = "delete FROM tbl_ScheduleExam WHERE status=0 and UserId="+uid + " and ExamID=" +ExamId +" and ExamRequestId=" + ExamRequestId;
            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, query);
            if (i > 0)
            {
                query = "Update tbl_ExamRequest set status=0,CurStatus='Not Scheduled' WHERE ExamRequestId=" + ExamRequestId;
                i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, query);
                
            }
            outMsg = "Record Updated";
            return i;

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public int ReScheduleExam(out string outMsg)
    {
        try
        {
            String query = "Update tbl_ExamRequest set status=0,CurStatus='Not Scheduled' WHERE  UserId=" + uid + " and ExamID=" + ExamId + " and ExamRequestId=" + ExamRequestId;
           
            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, query);
            if(i>0)
            outMsg = "Record Updated";
            else
            outMsg = "Record Not Updated";
            return i;

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public int CancelScheduleExamAll(out string outMsg)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[4];
            p[0] = new SqlParameter("@UserId", uid);
            p[1] = new SqlParameter("@ExamId", ExamId);
            p[2] = new SqlParameter("@ExamRequestId", ExamRequestId);
            p[3] = new SqlParameter("@Out", SqlDbType.VarChar, 15);
            p[3].Direction = ParameterDirection.Output;

            int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_CancelSchdule", p);
            outMsg = p[3].Value.ToString();
            return i;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }





    public int getExamDuration()
    {
        try
        {
            int outMsg = 0;
            SqlDataReader reader;
            string query = "Select Duration from tbl_Exams where ExamId='" +ExamId+ "'";
            reader = SqlHelper.ExecuteReader(Connection.con, CommandType.Text, query);

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    outMsg = reader.GetInt32(0);
                }
            }
            return outMsg;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }



   


    public int getExamination(out string outMsg)
    {
        try
        {
            outMsg = "";
            SqlDataReader reader;
            String query = "select batch from tbl_UserDetails,tbl_LoginDetails where tbl_UserDetails.UserId=tbl_LoginDetails.userID and tbl_LoginDetails.LoginId ='" + UserName + "'";
            reader = SqlHelper.ExecuteReader(Connection.con, CommandType.Text, query);
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    outMsg = reader.GetString(0).ToString();
                }
            }
            return 0;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }



   public int getExamTypeID(out string outMsg)
    {
        try
        {
            outMsg = "";
            SqlDataReader reader;
            string query = "Select ExamTypeId from tbl_ExamType where ExamTypeName='" + Examtypename + "'";
            reader = SqlHelper.ExecuteReader(Connection.con, CommandType.Text, query);

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    outMsg = reader.GetInt32(0).ToString();
                }
            }
            return 0;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public int getUserID(out string outMsg)
    {
        try
        {
            outMsg = "";
            SqlDataReader reader;
            string query = "Select userid from tbl_LoginDetails  where LoginId='" + UserName + "'";
            reader = SqlHelper.ExecuteReader(Connection.con, CommandType.Text, query);

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    outMsg = reader.GetInt32(0).ToString();
                }
            }
            return 0;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public int getName(out string outMsg)
    {
        try
        {
            outMsg = "";
            SqlDataReader reader;
            string query = "Select FName,LName from tbl_UserDetails  where userid='" + uid + "'";
            reader = SqlHelper.ExecuteReader(Connection.con, CommandType.Text, query);

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    outMsg = reader.GetString(0).ToString() +" "+ reader.GetString(1).ToString();
                }
            }
            return 0;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public String getUserName()
    {
        try
        {
         
            SqlDataReader reader;
            string query = "Select LoginId from tbl_LoginDetails  where userid='" + uid + "'";
            reader = SqlHelper.ExecuteReader(Connection.con, CommandType.Text, query);

            if (reader.HasRows)
            {
               while (reader.Read())
               {
                    return reader.GetString(0).ToString();
               }
            }
            return "Not Found";
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }








    public DataSet getExamID(string ExamTypeName)
    {
        try
        {
            string strCmdText = "Select ExamId from tbl_Exams where ExamTypeName='" + ExamTypeName + "'";
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public DataSet getExamTypeName()
    {
        try
        {
            string strCmdText = "Select ExamTypeName,ExamTypeId from tbl_ExamType";
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public DataSet getExamName(string id)
    {
        try
        {
            string strCmdText = "Select ExamName,ExamId from tbl_Exams where ExamTypeId='" + id + "'";
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }









       public DataSet getNotAttemptedExamId(int examtypeid)
    {
        try
        {
            string strCmdText = "Select ExamId,ExamName from tbl_Exams where Status=0 and examtypeid="+examtypeid;
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet getAttemptedExamId()
    {
        try
        {
            string strCmdText = "Select ExamId,ExamName from tbl_Exams where Status=1";
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    

    public DataSet gettblExamRequest()
    {
        try
        {
            string strCmdText = "select tbl_ExamRequest.UserId,PreferedDate,tbl_ExamRequest.ExamId,ExamName,tbl_ExamRequest.examtypeid,ExamRequestId,CurStatus,FName+'  '+LName as UserName from tbl_Exams,tbl_ExamRequest,tbl_UserDetails where tbl_ExamRequest.status=0 and tbl_UserDetails.Userid=tbl_ExamRequest.UserId and tbl_ExamRequest.ExamId=tbl_Exams.examid order by userid";
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }


    public DataSet gettblExamShedule()
    {
        try
        {
            string strCmdText = "select ExamRequestId,UserId,UserName,tbl_ScheduleExam.ExamId,ExamName,DateOfSchedule,dateOfExam from  tbl_ScheduleExam,tbl_Exams where tbl_ScheduleExam.ExamId=tbl_Exams.Examid and tbl_ScheduleExam.status=0 order by userid";
             return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public DataSet gettblReShedule()
    {
        try
        {
            string strCmdText = "select ExamRequestId,UserId,UserName,tbl_ScheduleExam.ExamId,ExamName,DateOfSchedule,dateOfExam from  tbl_ScheduleExam,tbl_Exams where tbl_ScheduleExam.ExamId=tbl_Exams.Examid and tbl_ScheduleExam.status=2 order by userid";
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public DataSet gettblUsers(string b)
    {
        try
        {
            string strCmdText = "SELECT tbl_UserDetails.UserId, loginId,FName,LName,ContactNo,Address,Batch,Password,status FROM tbl_UserDetails ,tbl_LoginDetails WHERE tbl_LoginDetails.userid=tbl_UserDetails.userid and status=0 and batch='";
            strCmdText = strCmdText + b+"'";
             return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public DataSet gettblActiveUsers(string b)
    {
        try
        {
            string strCmdText = "SELECT tbl_UserDetails.UserId, loginId,FName,LName,ContactNo,Address,Batch,Password,status FROM tbl_UserDetails ,tbl_LoginDetails WHERE tbl_LoginDetails.userid=tbl_UserDetails.userid and status=1 and batch='";
            strCmdText = strCmdText + b + "'";
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }




    public DataSet gettblStudentReport()
    {
        try
        {
            string strCmdText = "select UserId,tbl_ExamResult.ExamId,tbl_Exams.ExamName,NoOfQuestion,CorrectAnswers,WrongAnswers,Attempted,NetScore,TimeTaken,ExamAttendedDate from  tbl_ExamResult,tbl_Exams where tbl_ExamResult.ExamId=tbl_Exams.Examid and UserId="+uid;
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public DataSet gettblBatchReport()
    {
        try
        {
            string strCmdText = "select tbl_UserDetails.UserId,ExamId,tbl_UserDetails.FName+ '  '+tbl_UserDetails.LName as UserName,NoOfQuestion,CorrectAnswers,WrongAnswers,Attempted,NetScore,TimeTaken,ExamAttendedDate from  tbl_ExamResult,tbl_UserDetails where tbl_ExamResult.UserId=tbl_UserDetails.UserId and ExamId=" + ExamId + "order by NetScore desc, TimeTaken";
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }




    
    public DataSet ShowExamRequestDetails(int id,int reqid)
    {
        try
        {
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, "select * from tbl_ScheduleExam where ExamId=" + id + " and ExamRequestId="+reqid);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }




    public DataSet GetCheckStatus()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@UserName", UserName);
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "sp_GetCheckStatus", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }




    public DataSet GetRequests()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@UserName", UserName);

            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "sp_ViewRequests", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

}