﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using OnlineWebBasedExam;

public class BALLogin
{
	 
    public string username { get; set; }
    public string password { get; set; }

    public static string adminsLogins(string username, string password)
    {
        SqlParameter[] p = new SqlParameter[3];

        try
        {
            p[0] = new SqlParameter("@username", SqlDbType.VarChar, 50);
            p[0].Value = username;
            p[1] = new SqlParameter("@password", SqlDbType.VarChar, 50);
            p[1].Value = password;
            p[2] = new SqlParameter("@Role", SqlDbType.VarChar, 50);
            p[2].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "Sp_adminlogin", p);
            return p[2].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public static string Login(string username, string password)
    {
        SqlParameter[] p = new SqlParameter[3];

        try
        {
            p[0] = new SqlParameter("@username", SqlDbType.VarChar, 50);
            p[0].Value = username;
            p[1] = new SqlParameter("@password", SqlDbType.VarChar, 50);
            p[1].Value = password;
            p[2] = new SqlParameter("@Role", SqlDbType.VarChar, 50);
            p[2].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "Sp_login", p);
            return p[2].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
}
